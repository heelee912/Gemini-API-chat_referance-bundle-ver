from __future__ import annotations

import os
import shutil
import threading
import uuid
from pathlib import Path
from typing import Any

from .util import atomic_write_json, now_iso, sanitize_debug_obj


class Storage:
    def __init__(self, root_dir: Path):
        self._root_dir = root_dir
        self._lock = threading.RLock()
        self._chats_dir = self._root_dir / "chats"
        self._index_path = self._chats_dir / "index.json"
        self._debug_dir = self._root_dir / "debug"
        self._files_dir = self._root_dir / "files"
        self._batches_dir = self._root_dir / "batches"

        self._chats_dir.mkdir(parents=True, exist_ok=True)
        self._debug_dir.mkdir(parents=True, exist_ok=True)
        self._files_dir.mkdir(parents=True, exist_ok=True)
        self._batches_dir.mkdir(parents=True, exist_ok=True)

        if not self._index_path.exists():
            atomic_write_json(self._index_path, {"chats": []})

    def _chat_path(self, chat_id: str) -> Path:
        return self._chats_dir / f"{chat_id}.json"

    def _batch_path(self, batch_name: str) -> Path:
        safe = batch_name.replace("/", "__")
        return self._batches_dir / f"{safe}.json"

    def _read_json(self, path: Path) -> Any:
        return __import__("json").loads(path.read_text(encoding="utf-8"))

    def _write_json(self, path: Path, obj: Any) -> None:
        atomic_write_json(path, obj)

    def list_chats(self) -> list[dict[str, Any]]:
        with self._lock:
            idx = self._read_json(self._index_path)
            return idx.get("chats", [])

    def create_chat(self) -> dict[str, Any]:
        with self._lock:
            chat_id = uuid.uuid4().hex
            chat = {
                "id": chat_id,
                "title": "새 채팅",
                "createdAt": now_iso(),
                "updatedAt": now_iso(),
                "messages": [],
                "batchJobs": [],
                "bundles": [],
            }
            self._write_json(self._chat_path(chat_id), chat)
            idx = self._read_json(self._index_path)
            idx.setdefault("chats", [])
            idx["chats"].insert(0, {k: chat[k] for k in ["id", "title", "createdAt", "updatedAt"]})
            self._write_json(self._index_path, idx)
            return chat

    def get_chat(self, chat_id: str) -> dict[str, Any] | None:
        with self._lock:
            p = self._chat_path(chat_id)
            if not p.exists():
                return None
            return self._read_json(p)

    def update_chat_meta(self, chat_id: str, *, title: str | None = None) -> None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return
            if title is not None:
                chat["title"] = title
            chat["updatedAt"] = now_iso()
            self._write_json(self._chat_path(chat_id), chat)

            idx = self._read_json(self._index_path)
            chats = idx.get("chats", [])
            for row in chats:
                if row.get("id") == chat_id:
                    if title is not None:
                        row["title"] = title
                    row["updatedAt"] = chat["updatedAt"]
                    break
            self._write_json(self._index_path, idx)

    def append_message(self, chat_id: str, message: dict[str, Any]) -> None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                raise KeyError(f"chat not found: {chat_id}")
            chat["messages"].append(message)
            chat["updatedAt"] = now_iso()

            if chat.get("title") in (None, "", "새 채팅") and message.get("role") == "user":
                txt = (message.get("text") or "").strip()
                if txt:
                    chat["title"] = (txt[:30] + "…") if len(txt) > 30 else txt

            self._write_json(self._chat_path(chat_id), chat)

            idx = self._read_json(self._index_path)
            chats = idx.get("chats", [])
            found = None
            for i, row in enumerate(chats):
                if row.get("id") == chat_id:
                    found = chats.pop(i)
                    break
            row = found or {"id": chat_id, "createdAt": chat["createdAt"]}
            row["title"] = chat["title"]
            row["updatedAt"] = chat["updatedAt"]
            chats.insert(0, row)
            idx["chats"] = chats
            self._write_json(self._index_path, idx)

    def set_message(self, chat_id: str, message_id: str, patch: dict[str, Any]) -> dict[str, Any] | None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return None
            for i, m in enumerate(chat["messages"]):
                if m.get("id") == message_id:
                    merged = dict(m)
                    merged.update(patch)
                    chat["messages"][i] = merged
                    chat["updatedAt"] = now_iso()
                    self._write_json(self._chat_path(chat_id), chat)
                    return merged
            return None

    def save_debug(self, chat_id: str, message_id: str, debug_obj: Any) -> str:
        with self._lock:
            rel = f"debug/{chat_id}__{message_id}.json"
            path = self._root_dir / rel
            self._write_json(path, sanitize_debug_obj(debug_obj))
            return rel

    def load_debug(self, debug_rel_path: str) -> Any | None:
        with self._lock:
            p = (self._root_dir / debug_rel_path).resolve()
            if not str(p).startswith(str(self._root_dir.resolve())):
                return None
            if not p.exists():
                return None
            return self._read_json(p)

    def store_upload(self, chat_id: str, filename: str, data: bytes) -> dict[str, Any]:
        with self._lock:
            safe_name = filename.replace("\\", "_").replace("/", "_")
            subdir = self._files_dir / "uploads" / chat_id
            subdir.mkdir(parents=True, exist_ok=True)
            file_id = uuid.uuid4().hex
            path = subdir / f"{file_id}__{safe_name}"
            path.write_bytes(data)
            rel = str(path.relative_to(self._root_dir)).replace("\\", "/")
            return {"id": file_id, "name": safe_name, "path": rel, "bytes": len(data)}

    def store_bundle_image(self, chat_id: str, bundle_id: str, filename: str, data: bytes) -> dict[str, Any]:
        with self._lock:
            safe_name = filename.replace("\\", "_").replace("/", "_")
            subdir = self._files_dir / "bundles" / chat_id / bundle_id
            subdir.mkdir(parents=True, exist_ok=True)
            file_id = uuid.uuid4().hex
            path = subdir / f"{file_id}__{safe_name}"
            path.write_bytes(data)
            rel = str(path.relative_to(self._root_dir)).replace("\\", "/")
            return {"id": file_id, "name": safe_name, "path": rel, "bytes": len(data)}

    def store_generated(self, chat_id: str, filename: str, data: bytes) -> dict[str, Any]:
        with self._lock:
            safe_name = filename.replace("\\", "_").replace("/", "_")
            subdir = self._files_dir / "outputs" / chat_id
            subdir.mkdir(parents=True, exist_ok=True)
            file_id = uuid.uuid4().hex
            path = subdir / f"{file_id}__{safe_name}"
            path.write_bytes(data)
            rel = str(path.relative_to(self._root_dir)).replace("\\", "/")
            return {"id": file_id, "name": safe_name, "path": rel, "bytes": len(data)}

    def delete_chat(self, chat_id: str) -> None:
        with self._lock:
            p = self._chat_path(chat_id)
            if p.exists():
                p.unlink()

            uploads = self._files_dir / "uploads" / chat_id
            outputs = self._files_dir / "outputs" / chat_id
            bundles = self._files_dir / "bundles" / chat_id
            if uploads.exists():
                shutil.rmtree(uploads, ignore_errors=True)
            if outputs.exists():
                shutil.rmtree(outputs, ignore_errors=True)
            if bundles.exists():
                shutil.rmtree(bundles, ignore_errors=True)

            for dbg in self._debug_dir.glob(f"{chat_id}__*.json"):
                try:
                    dbg.unlink()
                except OSError:
                    pass

            idx = self._read_json(self._index_path)
            idx["chats"] = [c for c in idx.get("chats", []) if c.get("id") != chat_id]
            self._write_json(self._index_path, idx)

    def create_bundle(self, chat_id: str, *, title: str | None = None) -> dict[str, Any]:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                raise KeyError(f"chat not found: {chat_id}")
            bundles = chat.get("bundles")
            if not isinstance(bundles, list):
                bundles = []
            b_id = uuid.uuid4().hex
            bundle = {
                "id": b_id,
                "title": title or "새 번들",
                "prompt": "",
                "selected": False,
                "createdAt": now_iso(),
                "updatedAt": now_iso(),
                "images": [],
            }
            bundles.insert(0, bundle)
            chat["bundles"] = bundles
            chat["updatedAt"] = now_iso()
            self._write_json(self._chat_path(chat_id), chat)
            return bundle

    def update_bundle(self, chat_id: str, bundle_id: str, patch: dict[str, Any]) -> dict[str, Any] | None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return None
            bundles = chat.get("bundles")
            if not isinstance(bundles, list):
                bundles = []
            for b in bundles:
                if isinstance(b, dict) and b.get("id") == bundle_id:
                    if isinstance(patch.get("title"), str):
                        b["title"] = patch["title"]
                    if isinstance(patch.get("prompt"), str):
                        b["prompt"] = patch["prompt"]
                    if isinstance(patch.get("selected"), bool):
                        b["selected"] = patch["selected"]
                    b["updatedAt"] = now_iso()
                    chat["bundles"] = bundles
                    chat["updatedAt"] = now_iso()
                    self._write_json(self._chat_path(chat_id), chat)
                    return b
            return None

    def delete_bundle(self, chat_id: str, bundle_id: str) -> bool:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return False
            bundles = chat.get("bundles")
            if not isinstance(bundles, list):
                bundles = []
            new_bundles = [b for b in bundles if not (isinstance(b, dict) and b.get("id") == bundle_id)]
            if len(new_bundles) == len(bundles):
                return False
            chat["bundles"] = new_bundles
            chat["updatedAt"] = now_iso()
            self._write_json(self._chat_path(chat_id), chat)
            try:
                shutil.rmtree(self._files_dir / "bundles" / chat_id / bundle_id, ignore_errors=True)
            except Exception:
                pass
            return True

    def add_bundle_images(self, chat_id: str, bundle_id: str, images: list[dict[str, Any]]) -> dict[str, Any] | None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return None
            bundles = chat.get("bundles")
            if not isinstance(bundles, list):
                bundles = []
            for b in bundles:
                if isinstance(b, dict) and b.get("id") == bundle_id:
                    arr = b.get("images")
                    if not isinstance(arr, list):
                        arr = []
                    for im in images:
                        if isinstance(im, dict):
                            arr.append(im)
                    b["images"] = arr
                    b["updatedAt"] = now_iso()
                    chat["updatedAt"] = now_iso()
                    self._write_json(self._chat_path(chat_id), chat)
                    return b
            return None

    def delete_bundle_image(self, chat_id: str, bundle_id: str, image_id: str) -> bool:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return False
            bundles = chat.get("bundles")
            if not isinstance(bundles, list):
                bundles = []
            for b in bundles:
                if not (isinstance(b, dict) and b.get("id") == bundle_id):
                    continue
                arr = b.get("images")
                if not isinstance(arr, list):
                    arr = []
                removed = None
                new_arr = []
                for im in arr:
                    if isinstance(im, dict) and im.get("id") == image_id:
                        removed = im
                        continue
                    new_arr.append(im)
                if removed is None:
                    return False
                b["images"] = new_arr
                b["updatedAt"] = now_iso()
                chat["updatedAt"] = now_iso()
                self._write_json(self._chat_path(chat_id), chat)
                try:
                    p = removed.get("path")
                    if isinstance(p, str):
                        fp = (self._root_dir / p).resolve()
                        if str(fp).startswith(str(self._root_dir.resolve())) and fp.exists():
                            fp.unlink()
                except Exception:
                    pass
                return True
            return False

    def save_batch(self, batch_name: str, batch_obj: dict[str, Any]) -> None:
        with self._lock:
            self._write_json(self._batch_path(batch_name), batch_obj)

    def load_batch(self, batch_name: str) -> dict[str, Any] | None:
        with self._lock:
            p = self._batch_path(batch_name)
            if not p.exists():
                return None
            return self._read_json(p)

    def delete_batch(self, batch_name: str) -> None:
        with self._lock:
            p = self._batch_path(batch_name)
            if p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass

    def list_batches(self) -> list[dict[str, Any]]:
        with self._lock:
            out: list[dict[str, Any]] = []
            for p in sorted(self._batches_dir.glob("*.json")):
                try:
                    out.append(self._read_json(p))
                except Exception:
                    continue
            return out

    def update_batch(self, batch_name: str, patch: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            current = self.load_batch(batch_name) or {"name": batch_name}
            merged = dict(current)
            merged.update(patch)
            self.save_batch(batch_name, merged)
            return merged

    def add_chat_batch_job(self, chat_id: str, batch_name: str) -> None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return
            jobs = chat.get("batchJobs") or []
            if not isinstance(jobs, list):
                jobs = []
            if batch_name not in jobs:
                jobs.append(batch_name)
                chat["batchJobs"] = jobs
                chat["updatedAt"] = now_iso()
                self._write_json(self._chat_path(chat_id), chat)

    def remove_chat_batch_job(self, chat_id: str, batch_name: str) -> None:
        with self._lock:
            chat = self.get_chat(chat_id)
            if not chat:
                return
            jobs = chat.get("batchJobs") or []
            if not isinstance(jobs, list):
                jobs = []
            new_jobs = [n for n in jobs if n != batch_name]
            if new_jobs != jobs:
                chat["batchJobs"] = new_jobs
                chat["updatedAt"] = now_iso()
                self._write_json(self._chat_path(chat_id), chat)
