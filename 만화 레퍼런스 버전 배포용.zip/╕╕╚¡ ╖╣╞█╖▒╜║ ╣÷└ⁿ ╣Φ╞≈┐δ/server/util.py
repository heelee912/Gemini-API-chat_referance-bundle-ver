from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def json_dumps(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=False).encode(
        "utf-8"
    )


def safe_read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def atomic_write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    tmp.write_bytes(json_dumps(obj))
    os.replace(tmp, path)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def b64encode_bytes(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


_DEBUG_DROP_KEYS = {"thoughtSignature", "thought_signature"}
_DEBUG_INLINE_DATA_KEYS = {"inlineData", "inline_data"}


def sanitize_debug_obj(obj: Any, *, _path: tuple[str, ...] = ()) -> Any:
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            if k in _DEBUG_DROP_KEYS:
                continue
            if k == "data" and isinstance(v, str) and _path and _path[-1] in _DEBUG_INLINE_DATA_KEYS:
                out[k] = f"<omitted inlineData.data ({len(v)} chars)>"
                continue
            out[k] = sanitize_debug_obj(v, _path=(*_path, k))
        return out
    if isinstance(obj, list):
        return [sanitize_debug_obj(v, _path=_path) for v in obj]
    return obj


_ENV_LINE_RE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$")


def parse_env_file(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        m = _ENV_LINE_RE.match(raw_line)
        if not m:
            continue
        key, value = m.group(1), m.group(2).strip()
        if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
            value = value[1:-1]
        out[key] = value
    return out


@dataclass(frozen=True)
class ApiKeyStatus:
    loaded: bool
    key_hint: str | None


def load_api_key_from_root(root_dir: Path) -> tuple[str | None, ApiKeyStatus]:
    candidates = [root_dir / "env", root_dir / ".env", root_dir / "env.txt"]
    env: dict[str, str] = {}
    for p in candidates:
        if p.exists() and p.is_file():
            env.update(parse_env_file(safe_read_text(p)))

    key = (
        env.get("GEMINI_API_KEY")
        or env.get("GOOGLE_API_KEY")
        or env.get("GENAI_API_KEY")
        or env.get("API_KEY")
    )
    if not key:
        return None, ApiKeyStatus(loaded=False, key_hint=None)

    key_hint = ("*" * max(0, len(key) - 4)) + key[-4:]
    return key, ApiKeyStatus(loaded=True, key_hint=key_hint)
