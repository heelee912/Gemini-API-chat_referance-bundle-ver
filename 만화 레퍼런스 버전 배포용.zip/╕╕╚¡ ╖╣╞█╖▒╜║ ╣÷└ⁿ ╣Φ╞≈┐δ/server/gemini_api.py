from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GeminiApiError(Exception):
    status: int
    reason: str
    body_text: str | None
    body_json: Any | None

    def __str__(self) -> str:
        base = f"Gemini API error {self.status} {self.reason}"
        if self.body_text:
            return f"{base}: {self.body_text}"
        return base


class GeminiApi:
    def __init__(self, api_key: str, base_url: str = "https://generativelanguage.googleapis.com"):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self.last_response_headers: dict[str, str] | None = None

    def _url(self, path: str) -> str:
        if not path.startswith("/"):
            path = "/" + path
        return self._base_url + path

    def _request_json(self, method: str, path: str, body: Any | None = None) -> Any:
        data = None
        headers = {"x-goog-api-key": self._api_key}
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json; charset=utf-8"

        req = urllib.request.Request(self._url(path), data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                try:
                    self.last_response_headers = {k.lower(): str(v) for k, v in (resp.headers.items() if resp.headers else [])}
                except Exception:
                    self.last_response_headers = None
                raw = resp.read()
                if not raw:
                    return None
                return json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                self.last_response_headers = {k.lower(): str(v) for k, v in (e.headers.items() if e.headers else [])}
            except Exception:
                self.last_response_headers = None
            raw = e.read()
            text = raw.decode("utf-8", errors="replace") if raw else None
            parsed = None
            if text:
                try:
                    parsed = json.loads(text)
                except Exception:
                    parsed = None
            raise GeminiApiError(status=e.code, reason=e.reason, body_text=text, body_json=parsed)

    def generate_content(self, model: str, request: dict[str, Any]) -> Any:
        return self._request_json("POST", f"/v1beta/models/{model}:generateContent", request)

    def count_tokens(self, model: str, request: dict[str, Any]) -> Any:
        return self._request_json("POST", f"/v1beta/models/{model}:countTokens", request)

    def batch_generate_content(self, model: str, request: dict[str, Any]) -> Any:
        return self._request_json("POST", f"/v1beta/models/{model}:batchGenerateContent", request)

    def get_batch(self, name: str) -> Any:
        name = name.lstrip("/")
        return self._request_json("GET", f"/v1beta/{name}")

    def cancel_batch(self, name: str) -> Any:
        name = name.lstrip("/")
        return self._request_json("POST", f"/v1beta/{name}:cancel")

    def delete_batch(self, name: str) -> Any:
        name = name.lstrip("/")
        return self._request_json("DELETE", f"/v1beta/{name}")
