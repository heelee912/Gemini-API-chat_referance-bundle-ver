from __future__ import annotations

import argparse
import cgi
import copy
import io
import json
import mimetypes
import os
import posixpath
import re
import threading
import traceback
import uuid
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse
from zoneinfo import ZoneInfo

from .gemini_api import GeminiApi, GeminiApiError
from .storage import Storage
from .util import ApiKeyStatus, atomic_write_json, b64encode_bytes, load_api_key_from_root, now_iso, sanitize_debug_obj, sha256_bytes


ROOT_DIR = Path(__file__).resolve().parents[1]
WEB_DIR = ROOT_DIR / "web"
DATA_DIR = ROOT_DIR / "data"


MODELS: dict[str, dict[str, Any]] = {
    "gemini-3-pro-preview": {
        "label": "Gemini 3 Pro Preview",
        "supports": {
            "batch": True,
            "caching": True,
            "codeExecution": True,
            "functionCalling": True,
            "searchGrounding": True,
            "structuredOutput": True,
            "thinking": True,
            "urlContext": True,
            "imageGeneration": False,
        },
        "outputModalities": ["TEXT"],
    },
    "gemini-3-pro-image-preview": {
        "label": "Gemini 3 Pro Image Preview",
        "supports": {
            "batch": True,
            "caching": False,
            "codeExecution": False,
            "functionCalling": False,
            "searchGrounding": True,
            "structuredOutput": True,
            "thinking": True,
            "urlContext": False,
            "imageGeneration": True,
        },
        "outputModalities": ["TEXT", "IMAGE"],
    },
}


class Metrics:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._events: list[dict[str, Any]] = []
        self._usage_path = DATA_DIR / "usage.json"
        self._usage: dict[str, Any] = self._load_usage()
        self._last_rate_info: dict[str, Any] | None = None

    def _pt_day_key(self, when_utc: datetime | None = None) -> str:
        dt = when_utc or datetime.now(timezone.utc)
        try:
            tz = ZoneInfo("America/Los_Angeles")
        except Exception:
            return dt.strftime("%Y-%m-%d")
        return dt.astimezone(tz).strftime("%Y-%m-%d")

    def _load_usage(self) -> dict[str, Any]:
        try:
            if self._usage_path.exists():
                raw = self._usage_path.read_text(encoding="utf-8")
                obj = json.loads(raw)
                if isinstance(obj, dict):
                    obj.setdefault("tz", "America/Los_Angeles")
                    obj.setdefault("days", {})
                    return obj
        except Exception:
            pass
        return {"tz": "America/Los_Angeles", "days": {}}

    def _save_usage(self) -> None:
        atomic_write_json(self._usage_path, self._usage)

    def record(self, *, kind: str, model: str | None, tokens: dict[str, Any] | None, extra: dict[str, Any] | None = None) -> None:
        with self._lock:
            t = now_iso()
            self._events.append({"t": t, "kind": kind, "model": model, "tokens": tokens, "extra": extra})
            self._events = self._events[-2000:]

            if isinstance(extra, dict) and isinstance(extra.get("rateInfo"), dict):
                self._last_rate_info = extra.get("rateInfo")

            # Local per-day usage (PT day boundary per docs)
            day = self._pt_day_key()
            days = self._usage.setdefault("days", {})
            day_obj = days.setdefault(
                day,
                {
                    # User-facing usage (non-batch, excludes internal polling/estimation)
                    "calls": 0,
                    "tokens": {},
                    "errors": 0,
                    # Debug/diagnostics
                    "apiCalls": 0,
                    "apiCallsByScope": {},
                    "byKind": {},
                    "byModel": {},
                },
            )
            count_user = bool(isinstance(extra, dict) and extra.get("countAsUserUsage") is True)
            api_call = bool(isinstance(extra, dict) and extra.get("apiCall") is True)
            scope = (extra.get("scope") if isinstance(extra, dict) else None) or "unknown"

            if api_call:
                day_obj["apiCalls"] = int(day_obj.get("apiCalls") or 0) + 1
                by_scope = day_obj.setdefault("apiCallsByScope", {})
                if isinstance(by_scope, dict):
                    by_scope[scope] = int(by_scope.get(scope) or 0) + 1

            if count_user:
                day_obj["calls"] = int(day_obj.get("calls") or 0) + 1
            by_kind = day_obj.setdefault("byKind", {})
            by_kind[kind] = int(by_kind.get(kind) or 0) + 1
            if model:
                by_model = day_obj.setdefault("byModel", {})
                by_model[model] = int(by_model.get(model) or 0) + 1
            if count_user and (kind.endswith(".error") or kind.endswith(".failed")):
                day_obj["errors"] = int(day_obj.get("errors") or 0) + 1
            if count_user and isinstance(tokens, dict):
                tok = day_obj.setdefault("tokens", {})
                for k in ("promptTokenCount", "candidatesTokenCount", "totalTokenCount", "thoughtsTokenCount"):
                    v = tokens.get(k)
                    if isinstance(v, int):
                        tok[k] = int(tok.get(k) or 0) + v
            day_obj["updatedAt"] = t
            self._save_usage()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            day = self._pt_day_key()
            days = self._usage.get("days") if isinstance(self._usage.get("days"), dict) else {}
            today = days.get(day) if isinstance(days, dict) else None
            return {
                "events": list(self._events),
                "lastRateInfo": self._last_rate_info,
                "tz": self._usage.get("tz") or "America/Los_Angeles",
                "day": day,
                "today": today
                or {
                    "calls": 0,
                    "tokens": {},
                    "errors": 0,
                    "apiCalls": 0,
                    "apiCallsByScope": {},
                    "byKind": {},
                    "byModel": {},
                },
            }


class App:
    def __init__(self) -> None:
        self.storage = Storage(DATA_DIR)
        self.metrics = Metrics()
        self._key_lock = threading.Lock()
        self._api_key: str | None = None
        self._api_key_status: ApiKeyStatus = ApiKeyStatus(loaded=False, key_hint=None)
        self.reload_api_key()

    def reload_api_key(self) -> None:
        with self._key_lock:
            key, status = load_api_key_from_root(ROOT_DIR)
            self._api_key = key
            self._api_key_status = status

    def api(self) -> GeminiApi:
        with self._key_lock:
            if not self._api_key:
                raise RuntimeError("GEMINI_API_KEY not loaded (create env file)")
            return GeminiApi(self._api_key)

    def api_key_status(self) -> ApiKeyStatus:
        with self._key_lock:
            return self._api_key_status


APP = App()


def _strip_none(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _strip_none(v) for k, v in obj.items() if v is not None and v != "" and v != [] and v != {}}
    if isinstance(obj, list):
        return [_strip_none(v) for v in obj if v is not None]
    return obj


def _role_to_api(role: str) -> str:
    if role == "assistant":
        return "model"
    if role == "user":
        return "user"
    if role == "function":
        return "function"
    return role


def _guess_mime(filename: str) -> str:
    mime, _ = mimetypes.guess_type(filename)
    return mime or "application/octet-stream"


def _ext_from_mime(mime_type: str | None) -> str:
    m = (mime_type or "").lower()
    if "png" in m:
        return "png"
    if "jpeg" in m or "jpg" in m:
        return "jpg"
    if "webp" in m:
        return "webp"
    return "bin"


def _extract_text_from_response(resp: dict[str, Any]) -> str:
    texts: list[str] = []
    for cand in resp.get("candidates", []) or []:
        content = cand.get("content") or {}
        for part in content.get("parts", []) or []:
            t = part.get("text")
            if isinstance(t, str) and t.strip():
                if isinstance(part, dict) and part.get("thought"):
                    continue
                texts.append(t)
    return "\n".join(texts).strip()


def _extract_images_from_response(resp: dict[str, Any]) -> list[dict[str, Any]]:
    images: list[dict[str, Any]] = []
    for cand in resp.get("candidates", []) or []:
        content = cand.get("content") or {}
        for part in content.get("parts", []) or []:
            inline = part.get("inlineData") or part.get("inline_data")
            if not isinstance(inline, dict):
                continue
            mime = inline.get("mimeType") or inline.get("mime_type") or "application/octet-stream"
            data_b64 = inline.get("data")
            if not data_b64:
                continue
            images.append({"mimeType": mime, "data": data_b64})
    return images


def _extract_rate_info(headers: dict[str, str] | None) -> dict[str, str] | None:
    if not isinstance(headers, dict):
        return None
    out: dict[str, str] = {}
    for k, v in headers.items():
        key = str(k or "").lower()
        if key in ("retry-after", "x-goog-request-id"):
            out[key] = str(v)
            continue
        if "ratelimit" in key or "quota" in key:
            out[key] = str(v)
            continue
    return out or None


def _compile_selected_bundle_parts(chat_id: str, *, start_index: int = 1) -> tuple[list[dict[str, Any]], int, dict[str, Any] | None]:
    chat = APP.storage.get_chat(chat_id) or {}
    bundles = chat.get("bundles")
    if not isinstance(bundles, list):
        bundles = []
    selected = [b for b in bundles if isinstance(b, dict) and b.get("selected") is True]
    if not selected:
        return [], start_index, None

    idx = start_index
    parts: list[dict[str, Any]] = []
    compile_info: dict[str, Any] = {"selectedBundles": []}

    mapping_lines: list[str] = []
    for b in selected:
        title = str(b.get("title") or "번들")
        prompt = (b.get("prompt") or "").strip() if isinstance(b.get("prompt"), str) else ""
        images = b.get("images")
        if not isinstance(images, list):
            images = []

        bundle_nums: list[int] = []
        bundle_images_info: list[dict[str, Any]] = []
        bundle_image_parts: list[dict[str, Any]] = []

        for im in images:
            if not isinstance(im, dict):
                continue
            rel = im.get("path")
            if not isinstance(rel, str):
                continue
            p = DATA_DIR / rel
            if not p.exists():
                continue
            mime = im.get("mimeType") or _guess_mime(im.get("name") or "image")
            bundle_image_parts.append({"text": f"이미지 [{idx}]"})
            bundle_image_parts.append({"inlineData": {"mimeType": mime, "data": b64encode_bytes(p.read_bytes())}})
            bundle_nums.append(idx)
            bundle_images_info.append({"imageId": im.get("id"), "n": idx})
            idx += 1

        if bundle_nums:
            nums_str = ", ".join(f"[{n}]" for n in bundle_nums)
            mapping_lines.append(f'- "{title}": {nums_str}')
            header = f'번들 "{title}" 대상 이미지: {nums_str}'
        else:
            mapping_lines.append(f'- "{title}": (이미지 없음)')
            header = f'번들 "{title}" (이미지 없음)'

        # Place images first, then the bundle prompt with an explicit target header.
        parts.extend(bundle_image_parts)
        if prompt:
            parts.append({"text": f"{header}\n{prompt}"})
        else:
            parts.append({"text": header})

        compile_info["selectedBundles"].append(
            {
                "bundleId": b.get("id"),
                "title": title,
                "imageNums": bundle_nums,
                "images": bundle_images_info,
            }
        )

    rule_lines = [
        "규칙: 이 요청에서 이미지들은 [n] 형식으로 라벨링됩니다.",
        "답변에서 이미지를 언급할 때는 반드시 [n]으로만 지칭해 주세요.",
        "선택된 번들 이미지 매핑:",
        *mapping_lines,
    ]
    parts.insert(0, {"text": "\n".join(rule_lines)})
    compile_info["totalLabeledImages"] = idx - start_index
    return parts, idx, {"bundleCompile": compile_info}


def _compile_labeled_upload_parts(uploads: list[dict[str, Any]], *, start_index: int) -> tuple[list[dict[str, Any]], int]:
    idx = start_index
    parts: list[dict[str, Any]] = []
    for up in uploads or []:
        if not isinstance(up, dict):
            continue
        rel = up.get("path")
        if not isinstance(rel, str):
            continue
        p = DATA_DIR / rel
        if not p.exists():
            continue
        mime = up.get("mimeType") or _guess_mime(up.get("name") or "image")
        parts.append({"text": f"이미지 [{idx}]"})
        parts.append({"inlineData": {"mimeType": mime, "data": b64encode_bytes(p.read_bytes())}})
        idx += 1
    return parts, idx


def _requested_modalities(req: dict[str, Any]) -> set[str]:
    gen_cfg = req.get("generationConfig")
    if not isinstance(gen_cfg, dict):
        return set()
    mods = _get_any(gen_cfg, "responseModalities", "response_modalities")
    if not isinstance(mods, list):
        return set()
    out: set[str] = set()
    for m in mods:
        if isinstance(m, str) and m.strip():
            out.add(m.strip().upper())
    return out


def _maybe_add_fallback_text(api: GeminiApi, model: str, req: dict[str, Any], resp: dict[str, Any], *, images: list[dict[str, Any]], text: str) -> tuple[str, dict[str, Any] | None]:
    mods = _requested_modalities(req)
    if text or not images or not ({"TEXT", "IMAGE"} <= mods):
        return text, None

    req2 = copy.deepcopy(req)
    gen_cfg = req2.get("generationConfig")
    if not isinstance(gen_cfg, dict):
        gen_cfg = {}
        req2["generationConfig"] = gen_cfg
    gen_cfg["responseModalities"] = ["TEXT"]
    gen_cfg.pop("imageConfig", None)

    hint = "이미지 생성과 함께, 짧은 텍스트 답변도 1~3문장으로 작성해 주세요."
    sys_inst = req2.get("systemInstruction")
    if isinstance(sys_inst, dict) and isinstance(sys_inst.get("parts"), list):
        sys_inst["parts"].append({"text": hint})
    elif isinstance(sys_inst, dict):
        sys_inst["parts"] = [{"text": hint}]
    else:
        req2["systemInstruction"] = {"parts": [{"text": hint}]}

    debug: dict[str, Any] = {"fallbackText": {"ok": False, "attempts": []}}

    def _attempt(m: str) -> str | None:
        try:
            r = api.generate_content(m, req2)
        except Exception as e:
            debug["fallbackText"]["attempts"].append({"model": m, "ok": False, "error": str(e)})
            return None
        if not isinstance(r, dict):
            debug["fallbackText"]["attempts"].append({"model": m, "ok": False, "detail": "non_dict_response"})
            return None
        t = _extract_text_from_response(r)
        debug["fallbackText"]["attempts"].append({"model": m, "ok": bool(t), "response": r})
        return t or None

    t2 = _attempt(model)
    if not t2:
        t2 = _attempt("gemini-3-pro-preview")

    if not t2:
        return text, debug

    debug["fallbackText"]["ok"] = True
    debug["fallbackText"]["request"] = req2
    return t2, debug


def _extract_rich_parts_from_response(resp: dict[str, Any]) -> list[dict[str, Any]]:
    parts_out: list[dict[str, Any]] = []
    for cand in resp.get("candidates", []) or []:
        content = cand.get("content") or {}
        for part in content.get("parts", []) or []:
            if not isinstance(part, dict):
                continue

            text = part.get("text")
            if isinstance(text, str) and text.strip():
                if part.get("thought"):
                    parts_out.append({"type": "thought", "text": text})
                else:
                    parts_out.append({"type": "text", "text": text})

            fc = part.get("functionCall") or part.get("function_call")
            if isinstance(fc, dict) and fc.get("name"):
                parts_out.append({"type": "functionCall", "name": fc.get("name"), "args": fc.get("args")})

            fr = part.get("functionResponse") or part.get("function_response")
            if isinstance(fr, dict) and fr.get("name"):
                parts_out.append({"type": "functionResponse", "name": fr.get("name"), "response": fr.get("response")})

            code = part.get("executableCode") or part.get("executable_code")
            if isinstance(code, dict) and code.get("code"):
                parts_out.append({"type": "executableCode", "language": code.get("language"), "code": code.get("code")})

            cer = part.get("codeExecutionResult") or part.get("code_execution_result")
            if isinstance(cer, dict) and (cer.get("output") or cer.get("outcome")):
                parts_out.append({"type": "codeExecutionResult", "outcome": cer.get("outcome"), "output": cer.get("output")})

            if part.get("inlineData") or part.get("inline_data"):
                parts_out.append({"type": "inlineData"})
    return parts_out


def _get_any(d: dict[str, Any], *keys: str) -> Any:
    for k in keys:
        if k in d:
            return d[k]
    return None


def _terminal_batch_state(state: str | None) -> bool:
    return state in (
        "BATCH_STATE_SUCCEEDED",
        "BATCH_STATE_FAILED",
        "BATCH_STATE_CANCELLED",
        "BATCH_STATE_EXPIRED",
        "JOB_STATE_SUCCEEDED",
        "JOB_STATE_FAILED",
        "JOB_STATE_CANCELLED",
        "JOB_STATE_EXPIRED",
    )


def _extract_batch_from_get_response(resp: dict[str, Any]) -> dict[str, Any]:
    """
    The Batch API can return either:
    - Operation: {name, done, response?, error?, metadata?}
    - GenerateContentBatch: {name, state, output?, batchStats?, ...}
    """
    if "done" in resp:
        op = resp
        done = bool(op.get("done"))
        error = op.get("error")
        batch_from_response = None
        r = op.get("response")
        if isinstance(r, dict):
            batch_from_response = r.get("batch") if isinstance(r.get("batch"), dict) else r

        batch_from_metadata = None
        m = op.get("metadata")
        if isinstance(m, dict):
            if isinstance(m.get("batch"), dict):
                batch_from_metadata = m.get("batch")
            elif _get_any(m, "state") is not None or _get_any(m, "output") is not None:
                batch_from_metadata = m

        batch = batch_from_metadata or batch_from_response

        state = None
        if isinstance(batch_from_metadata, dict):
            state = _get_any(batch_from_metadata, "state")
        if state is None and isinstance(batch_from_response, dict):
            state = _get_any(batch_from_response, "state")

        return {"done": done, "state": state, "batch": batch, "error": error, "operation": op}

    state = _get_any(resp, "state")
    return {"done": _terminal_batch_state(state), "state": state, "batch": resp, "error": None, "operation": None}


class Handler(BaseHTTPRequestHandler):
    server_version = "GeminiLocalWebApp/0.1"

    def _parse_multipart_bytes(self, raw: bytes, content_type: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        m = re.search(r'boundary=(?:"([^"]+)"|([^;]+))', content_type)
        boundary = (m.group(1) or m.group(2)) if m else None
        if not boundary:
            raise ValueError("missing_boundary")
        bnd = boundary.encode("utf-8", errors="ignore")
        delim = b"--" + bnd

        fields: dict[str, Any] = {}
        files: list[dict[str, Any]] = []

        parts = raw.split(delim)
        for part in parts[1:]:
            if part.startswith(b"--"):
                break
            if part.startswith(b"\r\n"):
                part = part[2:]
            if part.endswith(b"\r\n"):
                part = part[:-2]
            if not part:
                continue

            header_blob, sep, body = part.partition(b"\r\n\r\n")
            if not sep:
                continue
            headers: dict[str, str] = {}
            for line in header_blob.split(b"\r\n"):
                if not line:
                    continue
                try:
                    s = line.decode("utf-8", errors="replace")
                except Exception:
                    continue
                k, _, v = s.partition(":")
                if not k:
                    continue
                headers[k.strip().lower()] = v.strip()

            cd = headers.get("content-disposition", "")
            params: dict[str, str] = {}
            for seg in cd.split(";")[1:]:
                seg = seg.strip()
                if "=" not in seg:
                    continue
                pk, pv = seg.split("=", 1)
                pv = pv.strip()
                if pv.startswith('"') and pv.endswith('"'):
                    pv = pv[1:-1]
                params[pk.strip().lower()] = pv

            name = params.get("name") or ""
            filename = params.get("filename")
            ctype = headers.get("content-type") or "application/octet-stream"

            if filename is not None:
                files.append({"field": name, "filename": filename, "contentType": ctype, "data": body})
            else:
                try:
                    fields[name] = body.decode("utf-8", errors="replace")
                except Exception:
                    fields[name] = ""

        return fields, files

    def _read_request_body_raw(self) -> bytes:
        # http.server does not transparently decode Transfer-Encoding: chunked.
        te = (self.headers.get("Transfer-Encoding", "") or "").lower()
        if "chunked" in te:
            out = bytearray()
            while True:
                line = self.rfile.readline()
                if not line:
                    break
                # chunk-size [; extensions]\r\n
                line = line.strip().split(b";", 1)[0]
                try:
                    size = int(line, 16)
                except ValueError:
                    break
                if size == 0:
                    # Consume trailing headers (if any) until blank line
                    while True:
                        trailer = self.rfile.readline()
                        if not trailer or trailer in (b"\r\n", b"\n"):
                            break
                    break
                chunk = self.rfile.read(size)
                out.extend(chunk)
                # consume CRLF after each chunk
                self.rfile.read(2)
            return bytes(out)

        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return b""
        return self.rfile.read(length)

    def _parse_multipart_form(self) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
        ctype = self.headers.get("Content-Type", "") or ""
        if "multipart/form-data" not in ctype:
            return None, {"ok": False, "error": "expected_multipart_form_data"}

        raw = self._read_request_body_raw()
        try:
            fields, files = self._parse_multipart_bytes(raw, ctype)
        except Exception as e:
            return None, {"ok": False, "error": "multipart_parse_failed", "detail": str(e)}

        diag = {
            "contentType": ctype,
            "contentLength": len(raw),
            "transferEncoding": self.headers.get("Transfer-Encoding"),
            "fieldNames": sorted([k for k in fields.keys() if k]),
            "fileFields": [{"field": f.get("field"), "filename": f.get("filename"), "bytes": len(f.get("data") or b"")} for f in files][:20],
        }
        return {"fields": fields, "files": files}, diag

    def _json(self, status: int, obj: Any) -> None:
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _text(self, status: int, text: str, content_type: str = "text/plain; charset=utf-8") -> None:
        data = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _not_found(self) -> None:
        self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found"})

    def _bad(self, message: str, *, detail: Any | None = None, status: int = 400) -> None:
        self._json(status, {"ok": False, "error": message, "detail": detail})

    def _serve_file(self, path: Path) -> None:
        if not path.exists() or not path.is_file():
            self._not_found()
            return
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            path = parsed.path

            if path == "/" or path == "/index.html":
                return self._serve_file(WEB_DIR / "index.html")
            if path == "/app.js":
                return self._serve_file(WEB_DIR / "app.js")
            if path == "/styles.css":
                return self._serve_file(WEB_DIR / "styles.css")

            if path.startswith("/files/"):
                rel = unquote(path[len("/files/") :])
                target = (ROOT_DIR / "data" / "files" / rel).resolve()
                root = (ROOT_DIR / "data" / "files").resolve()
                if not str(target).startswith(str(root)):
                    return self._bad("invalid_path", status=400)
                return self._serve_file(target)

            if path == "/api/status":
                APP.reload_api_key()
                ks = APP.api_key_status()
                return self._json(
                    200,
                    {
                        "ok": True,
                        "now": now_iso(),
                        "apiKeyLoaded": ks.loaded,
                        "apiKeyHint": ks.key_hint,
                        "models": MODELS,
                        "batchRateLimits": {
                            "concurrentBatches": 100,
                            "inputFileSizeLimitBytes": 2 * 1024 * 1024 * 1024,
                            "fileStorageLimitBytes": 20 * 1024 * 1024 * 1024,
                            "enqueuedTokensByTier": {
                                "tier1": {
                                    "gemini-3-pro-preview": 50_000_000,
                                    "gemini-3-pro-image-preview": 2_000_000,
                                },
                                "tier2": {
                                    "gemini-3-pro-preview": 500_000_000,
                                    "gemini-3-pro-image-preview": 270_000_000,
                                },
                                "tier3": {
                                    "gemini-3-pro-preview": 1_000_000_000,
                                    "gemini-3-pro-image-preview": 1_000_000_000,
                                },
                            },
                        },
                    },
                )

            if path == "/api/chats":
                return self._json(200, {"ok": True, "chats": APP.storage.list_chats()})

            if path.startswith("/api/chats/") and path.count("/") == 3:
                chat_id = path.split("/")[3]
                chat = APP.storage.get_chat(chat_id)
                if not chat:
                    return self._not_found()
                return self._json(200, {"ok": True, "chat": chat})

            if path.startswith("/api/debug/"):
                # /api/debug/<debugRelPath urlencoded>
                rel = unquote(path[len("/api/debug/") :])
                debug = APP.storage.load_debug(rel)
                if debug is None:
                    return self._not_found()
                return self._json(200, {"ok": True, "debug": sanitize_debug_obj(debug)})

            if path == "/api/metrics":
                return self._json(200, {"ok": True, "metrics": APP.metrics.snapshot()})

            if path == "/api/batches":
                batches = APP.storage.list_batches()
                return self._json(200, {"ok": True, "batches": batches})

            if path == "/api/batch":
                qs = parse_qs(parsed.query)
                name = (qs.get("name") or [None])[0]
                if not isinstance(name, str) or not name.startswith("batches/"):
                    return self._bad("invalid_batch_name")
                return self._handle_batch_poll(name)

            return self._not_found()
        except Exception as e:
            return self._json(
                500,
                {
                    "ok": False,
                    "error": "server_error",
                    "message": str(e),
                    "trace": traceback.format_exc(),
                },
            )

    def do_POST(self) -> None:
        try:
            parsed = urlparse(self.path)
            path = parsed.path

            if path == "/api/chats":
                chat = APP.storage.create_chat()
                return self._json(200, {"ok": True, "chat": chat})

            if path == "/api/messages":
                return self._handle_send_message()

            if path == "/api/bundles/create":
                body = self._read_json_body() or {}
                chat_id = body.get("chatId")
                title = body.get("title")
                if not isinstance(chat_id, str):
                    return self._bad("invalid_chat_id")
                try:
                    bundle = APP.storage.create_bundle(chat_id, title=title if isinstance(title, str) else None)
                except KeyError:
                    return self._not_found()
                return self._json(200, {"ok": True, "bundle": bundle})

            if path == "/api/bundles/update":
                body = self._read_json_body() or {}
                chat_id = body.get("chatId")
                bundle_id = body.get("bundleId")
                patch = body.get("patch") or {}
                if not isinstance(chat_id, str):
                    return self._bad("invalid_chat_id")
                if not isinstance(bundle_id, str):
                    return self._bad("invalid_bundle_id")
                if not isinstance(patch, dict):
                    return self._bad("invalid_patch")
                updated = APP.storage.update_bundle(chat_id, bundle_id, patch)
                if updated is None:
                    return self._not_found()
                return self._json(200, {"ok": True, "bundle": updated})

            if path == "/api/bundles/delete":
                body = self._read_json_body() or {}
                chat_id = body.get("chatId")
                bundle_id = body.get("bundleId")
                if not isinstance(chat_id, str):
                    return self._bad("invalid_chat_id")
                if not isinstance(bundle_id, str):
                    return self._bad("invalid_bundle_id")
                ok = APP.storage.delete_bundle(chat_id, bundle_id)
                if not ok:
                    return self._not_found()
                return self._json(200, {"ok": True})

            if path == "/api/bundles/images/add":
                form, diag = self._parse_multipart_form()
                if form is None:
                    return self._bad((diag or {}).get("error") or "expected_multipart_form_data", detail=diag)
                fields = form.get("fields") if isinstance(form, dict) else None
                files = form.get("files") if isinstance(form, dict) else None
                payload_raw = (fields or {}).get("payload") if isinstance(fields, dict) else None
                if not payload_raw:
                    return self._bad("missing_payload")
                try:
                    payload = json.loads(payload_raw)
                except Exception:
                    return self._bad("invalid_payload_json")
                chat_id = payload.get("chatId")
                bundle_id = payload.get("bundleId")
                if not isinstance(chat_id, str):
                    return self._bad("invalid_chat_id")
                if not isinstance(bundle_id, str):
                    return self._bad("invalid_bundle_id")
                chat = APP.storage.get_chat(chat_id)
                if not chat:
                    return self._not_found()
                bundles = chat.get("bundles")
                if not isinstance(bundles, list) or not any(isinstance(b, dict) and b.get("id") == bundle_id for b in bundles):
                    return self._not_found()

                added: list[dict[str, Any]] = []
                for item in (files or []) if isinstance(files, list) else []:
                    if not isinstance(item, dict):
                        continue
                    if item.get("field") != "files":
                        continue
                    filename = item.get("filename") or "file"
                    file_bytes = item.get("data") if isinstance(item.get("data"), (bytes, bytearray)) else b""
                    mime = item.get("contentType") or _guess_mime(filename)
                    stored = APP.storage.store_bundle_image(chat_id, bundle_id, filename, file_bytes)
                    added.append(
                        {
                            "id": stored.get("id"),
                            "name": stored.get("name"),
                            "path": stored.get("path"),
                            "bytes": stored.get("bytes"),
                            "mimeType": mime,
                            "sha256": sha256_bytes(file_bytes),
                        }
                    )
                updated = APP.storage.add_bundle_images(chat_id, bundle_id, added)
                if updated is None:
                    return self._not_found()
                return self._json(200, {"ok": True, "bundle": updated, "added": added})

            if path == "/api/bundles/images/delete":
                body = self._read_json_body() or {}
                chat_id = body.get("chatId")
                bundle_id = body.get("bundleId")
                image_id = body.get("imageId")
                if not isinstance(chat_id, str):
                    return self._bad("invalid_chat_id")
                if not isinstance(bundle_id, str):
                    return self._bad("invalid_bundle_id")
                if not isinstance(image_id, str):
                    return self._bad("invalid_image_id")
                ok = APP.storage.delete_bundle_image(chat_id, bundle_id, image_id)
                if not ok:
                    return self._not_found()
                return self._json(200, {"ok": True})

            if path == "/api/batches/cancel":
                body = self._read_json_body()
                name = (body or {}).get("name")
                if not isinstance(name, str) or not name.startswith("batches/"):
                    return self._bad("invalid_batch_name")
                api = APP.api()
                try:
                    api.cancel_batch(name)
                except GeminiApiError as e:
                    return self._json(502, {"ok": False, "error": "gemini_error", "detail": e.body_json or e.body_text})
                return self._json(200, {"ok": True})

            if path == "/api/batches/cleanup":
                # Best-effort cleanup of locally-tracked batches
                cleaned: list[str] = []
                api = APP.api()
                for rec in APP.storage.list_batches():
                    name = rec.get("name")
                    if not isinstance(name, str) or not name.startswith("batches/"):
                        continue
                    try:
                        api.cancel_batch(name)
                    except Exception:
                        pass
                    try:
                        api.delete_batch(name)
                    except Exception:
                        pass
                    APP.storage.delete_batch(name)
                    cleaned.append(name)
                    chat_id = rec.get("chatId")
                    if isinstance(chat_id, str):
                        APP.storage.remove_chat_batch_job(chat_id, name)
                return self._json(200, {"ok": True, "cleaned": cleaned})

            return self._not_found()
        except Exception as e:
            return self._json(
                500,
                {
                    "ok": False,
                    "error": "server_error",
                    "message": str(e),
                    "trace": traceback.format_exc(),
                },
            )

    def do_DELETE(self) -> None:
        try:
            parsed = urlparse(self.path)
            path = parsed.path

            if path.startswith("/api/chats/") and path.count("/") == 3:
                chat_id = path.split("/")[3]
                chat = APP.storage.get_chat(chat_id)
                if not chat:
                    return self._not_found()
                # Best-effort: cancel/delete remote batch jobs first
                try:
                    api = APP.api()
                except Exception:
                    api = None
                for name in chat.get("batchJobs", []) or []:
                    if api:
                        try:
                            api.cancel_batch(name)
                        except Exception:
                            pass
                        try:
                            api.delete_batch(name)
                        except Exception:
                            pass
                    APP.storage.delete_batch(name)
                APP.storage.delete_chat(chat_id)
                return self._json(200, {"ok": True})

            return self._not_found()
        except Exception as e:
            return self._json(
                500,
                {
                    "ok": False,
                    "error": "server_error",
                    "message": str(e),
                    "trace": traceback.format_exc(),
                },
            )

    def _read_json_body(self) -> Any:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return None
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def _handle_send_message(self) -> None:
        form, diag = self._parse_multipart_form()
        if form is None:
            return self._bad((diag or {}).get("error") or "expected_multipart_form_data", detail=diag)
        fields = form.get("fields") if isinstance(form, dict) else None
        files = form.get("files") if isinstance(form, dict) else None
        payload_raw = (fields or {}).get("payload") if isinstance(fields, dict) else None
        if not payload_raw:
            return self._bad("missing_payload")
        try:
            payload = json.loads(payload_raw)
        except Exception:
            return self._bad("invalid_payload_json")

        chat_id = payload.get("chatId")
        if chat_id is None:
            chat = APP.storage.create_chat()
            chat_id = chat["id"]
        if not isinstance(chat_id, str):
            return self._bad("invalid_chat_id")

        model = payload.get("model") or "gemini-3-pro-preview"
        if model not in MODELS:
            return self._bad("invalid_model")

        mode = payload.get("sendMode") or "sync"
        if mode not in ("sync", "batch"):
            return self._bad("invalid_send_mode")

        text = (payload.get("text") or "").strip()
        if not text and not form.getlist("files"):
            return self._bad("empty_message")

        uploaded: list[dict[str, Any]] = []
        received_files: list[dict[str, Any]] = []
        for item in (files or []) if isinstance(files, list) else []:
            if not isinstance(item, dict):
                continue
            if item.get("field") != "files":
                continue
            filename = item.get("filename") or "file"
            file_bytes = item.get("data") if isinstance(item.get("data"), (bytes, bytearray)) else b""
            mime = item.get("contentType") or _guess_mime(filename)
            received_files.append({"name": filename, "mimeType": mime, "bytes": len(file_bytes)})
            uploaded.append(
                {
                    **APP.storage.store_upload(chat_id, filename, file_bytes),
                    "mimeType": mime,
                    "sha256": sha256_bytes(file_bytes),
                }
            )

        user_msg_id = uuid.uuid4().hex
        user_message = {
            "id": user_msg_id,
            "role": "user",
            "createdAt": now_iso(),
            "text": text,
            "uploads": uploaded,
        }
        APP.storage.append_message(chat_id, user_message)

        settings = payload.get("settings") or {}
        if not isinstance(settings, dict):
            settings = {}
        bundle_parts, next_idx, dbg_extra = _compile_selected_bundle_parts(chat_id, start_index=1)
        override_parts: dict[str, list[dict[str, Any]]] | None = None
        if bundle_parts:
            # When bundle prompts are selected, compile this user turn deterministically:
            # bundle headers/images/prompts -> (optional) this message uploads labeled -> this message text.
            extra_upload_parts, _ = _compile_labeled_upload_parts(uploaded, start_index=next_idx)
            compiled_parts: list[dict[str, Any]] = []
            compiled_parts.extend(bundle_parts)
            if extra_upload_parts:
                compiled_parts.append({"text": "추가 첨부 이미지:"})
                compiled_parts.extend(extra_upload_parts)
            if text:
                compiled_parts.append({"text": text})
            override_parts = {user_msg_id: compiled_parts}
        req = self._build_generate_request(chat_id, model, settings, override_message_parts=override_parts)

        if mode == "sync":
            return self._send_sync(chat_id, model, user_msg_id, req, received_files=received_files, upload_diag=diag, debug_extra=dbg_extra)
        estimate = bool(settings.get("estimateBatchTokens", True))
        return self._send_batch(chat_id, model, user_msg_id, req, settings=settings, estimate_tokens=estimate, debug_extra=dbg_extra)

    def _build_generate_request(
        self,
        chat_id: str,
        model: str,
        settings: dict[str, Any],
        *,
        until_message_id: str | None = None,
        override_message_parts: dict[str, list[dict[str, Any]]] | None = None,
    ) -> dict[str, Any]:
        chat = APP.storage.get_chat(chat_id) or {}

        contents: list[dict[str, Any]] = []
        for m in chat.get("messages", []) or []:
            role = m.get("role")
            if role not in ("user", "assistant", "function"):
                continue
            parts: list[dict[str, Any]] = []
            mid = m.get("id")
            if isinstance(override_message_parts, dict) and isinstance(mid, str) and isinstance(override_message_parts.get(mid), list):
                parts = override_message_parts.get(mid) or []
            else:
                t = (m.get("text") or "").strip()
                if t:
                    parts.append({"text": t})

                for up in m.get("uploads", []) or []:
                    rel = up.get("path")
                    if not isinstance(rel, str):
                        continue
                    p = DATA_DIR / rel
                    if not p.exists():
                        continue
                    parts.append(
                        {
                            "inlineData": {
                                "mimeType": up.get("mimeType") or _guess_mime(up.get("name") or "file"),
                                "data": b64encode_bytes(p.read_bytes()),
                            }
                        }
                    )

                for out in m.get("outputs", []) or []:
                    rel = out.get("path")
                    if not isinstance(rel, str):
                        continue
                    p = DATA_DIR / rel
                    if not p.exists():
                        continue
                    parts.append(
                        {
                            "inlineData": {
                                "mimeType": out.get("mimeType") or _guess_mime(out.get("name") or "image"),
                                "data": b64encode_bytes(p.read_bytes()),
                            }
                        }
                    )

            if parts:
                contents.append({"role": _role_to_api(role), "parts": parts})
            if until_message_id and m.get("id") == until_message_id:
                break

        gen_cfg = settings.get("generationConfig") or {}
        tools = settings.get("tools") or []
        tool_cfg = settings.get("toolConfig") or None
        safety = settings.get("safetySettings") or []
        system_text = (settings.get("systemInstruction") or "").strip()
        cached = (settings.get("cachedContent") or "").strip() or None

        request: dict[str, Any] = {"contents": contents}
        if system_text:
            request["systemInstruction"] = {"parts": [{"text": system_text}]}
        if isinstance(gen_cfg, dict) and gen_cfg:
            request["generationConfig"] = gen_cfg
        if isinstance(tools, list) and tools:
            request["tools"] = tools
        if isinstance(tool_cfg, dict) and tool_cfg:
            request["toolConfig"] = tool_cfg
        if isinstance(safety, list) and safety:
            request["safetySettings"] = safety
        if cached:
            request["cachedContent"] = cached

        return _strip_none(request)

    def _send_sync(
        self,
        chat_id: str,
        model: str,
        user_msg_id: str,
        req: dict[str, Any],
        *,
        received_files: list[dict[str, Any]] | None = None,
        upload_diag: dict[str, Any] | None = None,
        debug_extra: dict[str, Any] | None = None,
    ) -> None:
        api = APP.api()
        assistant_msg_id = uuid.uuid4().hex
        try:
            resp = api.generate_content(model, req)
            APP.metrics.record(
                kind="generateContent",
                model=model,
                tokens=(resp.get("usageMetadata") if isinstance(resp, dict) else None),
                extra={
                    "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                    "apiCall": True,
                    "scope": "interactive",
                    "countAsUserUsage": True,
                },
            )
        except GeminiApiError as e:
            APP.metrics.record(
                kind="generateContent.error",
                model=model,
                tokens=None,
                extra={
                    "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                    "apiCall": True,
                    "scope": "interactive",
                    "countAsUserUsage": True,
                },
            )
            debug_rel = APP.storage.save_debug(
                chat_id,
                assistant_msg_id,
                {"request": req, "error": {"status": e.status, "reason": e.reason, "body": e.body_json or e.body_text}},
            )
            msg = {
                "id": assistant_msg_id,
                "role": "assistant",
                "createdAt": now_iso(),
                "text": "오류가 발생했습니다. (디버그 보기에서 상세 확인 가능)",
                "error": {"status": e.status, "reason": e.reason},
                "debugPath": debug_rel,
            }
            APP.storage.append_message(chat_id, msg)
            return self._json(502, {"ok": False, "error": "gemini_error", "chatId": chat_id, "message": msg})

        resp_dict = resp if isinstance(resp, dict) else {}
        text = _extract_text_from_response(resp_dict)
        parts = _extract_rich_parts_from_response(resp_dict)
        images = _extract_images_from_response(resp_dict)
        outputs: list[dict[str, Any]] = []
        for idx, img in enumerate(images):
            try:
                import base64

                raw = base64.b64decode(img["data"])
                ext = _ext_from_mime(img.get("mimeType"))
                outputs.append(
                    {
                        **APP.storage.store_generated(chat_id, f"gen_{assistant_msg_id}_{idx}.{ext}", raw),
                        "mimeType": img.get("mimeType"),
                    }
                )
            except Exception:
                continue

        fallback_debug: dict[str, Any] | None = None
        if isinstance(resp_dict, dict):
            text, fallback_debug = _maybe_add_fallback_text(api, model, req, resp_dict, images=images, text=text)
            if fallback_debug and isinstance(fallback_debug.get("fallbackText"), dict):
                tokens = None
                if fallback_debug["fallbackText"].get("ok"):
                    for att in reversed(fallback_debug["fallbackText"].get("attempts") or []):
                        if isinstance(att, dict) and att.get("ok") and isinstance(att.get("response"), dict):
                            tokens = att["response"].get("usageMetadata")
                            break
                APP.metrics.record(
                    kind="generateContent.fallbackText",
                    model=model,
                    tokens=tokens,
                    extra={
                        "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                        "apiCall": True,
                        "scope": "interactive",
                        "countAsUserUsage": True,
                    },
                )

        debug_obj: dict[str, Any] = {"request": req, "response": resp_dict}
        if received_files is not None:
            debug_obj["receivedFiles"] = received_files
        if upload_diag is not None:
            debug_obj["uploadDiag"] = upload_diag
        if isinstance(debug_extra, dict) and debug_extra:
            debug_obj.update(debug_extra)
        if fallback_debug:
            debug_obj.update(fallback_debug)
        debug_rel = APP.storage.save_debug(chat_id, assistant_msg_id, debug_obj)
        msg = {
            "id": assistant_msg_id,
            "role": "assistant",
            "createdAt": now_iso(),
            "text": text,
            "parts": parts,
            "outputs": outputs,
            "usage": (resp.get("usageMetadata") if isinstance(resp, dict) else None),
            "debugPath": debug_rel,
        }
        APP.storage.append_message(chat_id, msg)
        return self._json(200, {"ok": True, "chatId": chat_id, "message": msg})

    def _send_batch(
        self,
        chat_id: str,
        model: str,
        user_msg_id: str,
        req: dict[str, Any],
        *,
        settings: dict[str, Any],
        estimate_tokens: bool,
        debug_extra: dict[str, Any] | None = None,
    ) -> None:
        api = APP.api()
        assistant_msg_id = uuid.uuid4().hex
        placeholder_dbg_obj: dict[str, Any] = {"request": req, "batch": {"status": "pending"}}
        if isinstance(debug_extra, dict) and debug_extra:
            placeholder_dbg_obj.update(debug_extra)
        placeholder_debug = APP.storage.save_debug(chat_id, assistant_msg_id, placeholder_dbg_obj)
        placeholder = {
            "id": assistant_msg_id,
            "role": "assistant",
            "createdAt": now_iso(),
            "text": "배치 작업 실행 중입니다. 완료될 때까지 잠시만 기다려 주세요.",
            "batch": {"state": "pending"},
            "debugPath": placeholder_debug,
        }
        APP.storage.append_message(chat_id, placeholder)

        estimated_input_tokens: int | None = None
        if estimate_tokens:
            try:
                ct = api.count_tokens(model, {"generateContentRequest": req})
                if isinstance(ct, dict) and isinstance(ct.get("totalTokens"), int):
                    estimated_input_tokens = ct["totalTokens"]
                    APP.metrics.record(
                        kind="countTokens",
                        model=model,
                        tokens={"promptTokenCount": estimated_input_tokens},
                        extra={
                            "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                            "apiCall": True,
                            "scope": "internal",
                            "countAsUserUsage": False,
                        },
                    )
            except Exception:
                pass

        batch_req = {
            "batch": {
                "displayName": f"chat-{chat_id[:8]}-{user_msg_id[:8]}",
                "model": f"models/{model}",
                "inputConfig": {
                    "requests": {
                        "requests": [
                            {
                                "request": req,
                                "metadata": {"chatId": chat_id, "userMessageId": user_msg_id, "assistantMessageId": assistant_msg_id},
                            }
                        ]
                    }
                },
            }
        }
        try:
            op = api.batch_generate_content(model, batch_req)
            APP.metrics.record(
                kind="batchGenerateContent",
                model=model,
                tokens=None,
                extra={
                    "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                    "apiCall": True,
                    "scope": "batch",
                    "countAsUserUsage": False,
                },
            )
        except GeminiApiError as e:
            debug_rel = APP.storage.save_debug(
                chat_id,
                assistant_msg_id,
                {"request": batch_req, "error": {"status": e.status, "reason": e.reason, "body": e.body_json or e.body_text}},
            )
            APP.storage.set_message(
                chat_id,
                assistant_msg_id,
                {
                    "text": "배치 작업 생성에 실패했습니다. (디버그 보기에서 상세 확인 가능)",
                    "error": {"status": e.status, "reason": e.reason},
                    "debugPath": debug_rel,
                    "batch": {"state": "failed"},
                },
            )
            return self._json(502, {"ok": False, "error": "gemini_error", "chatId": chat_id})

        batch_name = (op or {}).get("name")
        if not isinstance(batch_name, str) or not batch_name.startswith("batches/"):
            batch_name = f"batches/{uuid.uuid4().hex}"

        requested_modalities = sorted(_requested_modalities(req))
        APP.storage.save_batch(
            batch_name,
            {
                "name": batch_name,
                "chatId": chat_id,
                "userMessageId": user_msg_id,
                "assistantMessageId": assistant_msg_id,
                "model": model,
                "createdAt": now_iso(),
                "state": "BATCH_STATE_PENDING",
                "estimatedInputTokens": estimated_input_tokens,
                "requestedModalities": requested_modalities,
                "settings": settings,
            },
        )

        APP.storage.set_message(
            chat_id,
            assistant_msg_id,
            {"batch": {"name": batch_name, "state": "pending", "estimatedInputTokens": estimated_input_tokens}},
        )
        APP.storage.add_chat_batch_job(chat_id, batch_name)

        return self._json(
            200,
            {
                "ok": True,
                "chatId": chat_id,
                "message": placeholder,
                "batch": {"name": batch_name},
            },
        )

    def _handle_batch_poll(self, batch_name: str) -> None:
        record = APP.storage.load_batch(batch_name) or {}
        chat_id = record.get("chatId")
        assistant_msg_id = record.get("assistantMessageId")
        model = record.get("model")

        if not isinstance(chat_id, str) or not isinstance(assistant_msg_id, str):
            return self._bad("unknown_batch")

        api = APP.api()
        try:
            resp = api.get_batch(batch_name)
            APP.metrics.record(
                kind="batches.get",
                model=model if isinstance(model, str) else None,
                tokens=None,
                extra={
                    "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                    "apiCall": True,
                    "scope": "internal",
                    "countAsUserUsage": False,
                },
            )
        except GeminiApiError as e:
            return self._json(502, {"ok": False, "error": "gemini_error", "detail": e.body_json or e.body_text})

        if not isinstance(resp, dict):
            return self._json(502, {"ok": False, "error": "unexpected_batch_response"})

        info = _extract_batch_from_get_response(resp)
        state = info.get("state") or "UNKNOWN"
        batch_obj = info.get("batch") if isinstance(info.get("batch"), dict) else None
        APP.storage.update_batch(batch_name, {"state": state, "updatedAt": now_iso()})

        if not info.get("done"):
            APP.storage.set_message(chat_id, assistant_msg_id, {"batch": {"name": batch_name, "state": state}})
            return self._json(200, {"ok": True, "done": False, "state": state})

        # Terminal
        if info.get("error"):
            debug_rel = APP.storage.save_debug(chat_id, assistant_msg_id, {"batch": {"name": batch_name}, "error": info.get("error"), "raw": resp})
            APP.storage.set_message(
                chat_id,
                assistant_msg_id,
                {
                    "text": "배치 작업이 실패했습니다. (디버그 보기에서 상세 확인 가능)",
                    "error": info.get("error"),
                    "batch": {"name": batch_name, "state": state},
                    "debugPath": debug_rel,
                },
            )
            self._finalize_batch(chat_id, batch_name)
            return self._json(200, {"ok": True, "done": True, "state": state})

        output = None
        if isinstance(batch_obj, dict):
            output = _get_any(batch_obj, "output")
            if not isinstance(output, dict) and _get_any(batch_obj, "inlinedResponses", "inlined_responses") is not None:
                output = batch_obj
        if not isinstance(output, dict) and isinstance(resp, dict) and "done" in resp:
            op_resp = resp.get("response")
            if isinstance(op_resp, dict):
                resp_like = op_resp.get("batch") if isinstance(op_resp.get("batch"), dict) else op_resp
                out = _get_any(resp_like, "output")
                if isinstance(out, dict):
                    output = out
                elif _get_any(resp_like, "inlinedResponses", "inlined_responses") is not None:
                    output = resp_like
        if not isinstance(output, dict) and isinstance(resp, dict) and "done" in resp:
            op_meta = resp.get("metadata")
            if isinstance(op_meta, dict):
                meta_like = op_meta.get("batch") if isinstance(op_meta.get("batch"), dict) else op_meta
                out = _get_any(meta_like, "output")
                if isinstance(out, dict):
                    output = out
        if not isinstance(output, dict):
            debug_rel = APP.storage.save_debug(chat_id, assistant_msg_id, {"batch": {"name": batch_name}, "raw": resp})
            APP.storage.set_message(
                chat_id,
                assistant_msg_id,
                {
                    "text": "배치 작업이 완료되었지만 결과를 찾지 못했습니다. (디버그 보기에서 상세 확인 가능)",
                    "batch": {"name": batch_name, "state": state},
                    "debugPath": debug_rel,
                },
            )
            self._finalize_batch(chat_id, batch_name)
            return self._json(200, {"ok": True, "done": True, "state": state})

        inlined = _get_any(output, "inlinedResponses", "inlined_responses")
        if isinstance(inlined, dict):
            inlined_list = _get_any(inlined, "inlinedResponses", "inlined_responses") or []
        else:
            inlined_list = []
        first = inlined_list[0] if isinstance(inlined_list, list) and inlined_list else None

        if isinstance(first, dict) and first.get("error"):
            debug_rel = APP.storage.save_debug(chat_id, assistant_msg_id, {"batch": {"name": batch_name}, "raw": resp})
            APP.storage.set_message(
                chat_id,
                assistant_msg_id,
                {
                    "text": "배치 요청 처리 중 오류가 발생했습니다. (디버그 보기에서 상세 확인 가능)",
                    "error": first.get("error"),
                    "batch": {"name": batch_name, "state": state},
                    "debugPath": debug_rel,
                },
            )
            self._finalize_batch(chat_id, batch_name)
            return self._json(200, {"ok": True, "done": True, "state": state})

        gen_resp = first.get("response") if isinstance(first, dict) else None
        if not isinstance(gen_resp, dict):
            debug_rel = APP.storage.save_debug(chat_id, assistant_msg_id, {"batch": {"name": batch_name}, "raw": resp})
            APP.storage.set_message(
                chat_id,
                assistant_msg_id,
                {
                    "text": "배치 결과 형식이 예상과 다릅니다. (디버그 보기에서 상세 확인 가능)",
                    "batch": {"name": batch_name, "state": state},
                    "debugPath": debug_rel,
                },
            )
            self._finalize_batch(chat_id, batch_name)
            return self._json(200, {"ok": True, "done": True, "state": state})

        APP.metrics.record(kind="batch.result", model=model if isinstance(model, str) else None, tokens=gen_resp.get("usageMetadata"))

        text = _extract_text_from_response(gen_resp)
        parts = _extract_rich_parts_from_response(gen_resp)
        images = _extract_images_from_response(gen_resp)
        fallback_debug: dict[str, Any] | None = None
        requested = record.get("requestedModalities")
        if not text and images and isinstance(requested, list):
            requested_set = {str(x).upper() for x in requested if isinstance(x, str)}
            if {"TEXT", "IMAGE"} <= requested_set:
                model_str = model if isinstance(model, str) and model else "gemini-3-pro-preview"
                settings = record.get("settings") if isinstance(record.get("settings"), dict) else {}
                user_message_id = record.get("userMessageId") if isinstance(record.get("userMessageId"), str) else None
                req0 = self._build_generate_request(chat_id, model_str, settings, until_message_id=user_message_id)
                text, fallback_debug = _maybe_add_fallback_text(api, model_str, req0, gen_resp, images=images, text=text)
                if fallback_debug and isinstance(fallback_debug.get("fallbackText"), dict):
                    tokens = None
                    if fallback_debug["fallbackText"].get("ok"):
                        for att in reversed(fallback_debug["fallbackText"].get("attempts") or []):
                            if isinstance(att, dict) and att.get("ok") and isinstance(att.get("response"), dict):
                                tokens = att["response"].get("usageMetadata")
                                break
                    APP.metrics.record(
                        kind="batch.result.fallbackText",
                        model=model_str,
                        tokens=tokens,
                        extra={
                            "rateInfo": _extract_rate_info(getattr(api, "last_response_headers", None)),
                            "apiCall": True,
                            "scope": "interactive",
                            "countAsUserUsage": True,
                        },
                    )

        outputs: list[dict[str, Any]] = []
        for idx, img in enumerate(images):
            try:
                import base64

                raw = base64.b64decode(img["data"])
                ext = _ext_from_mime(img.get("mimeType"))
                outputs.append(
                    {
                        **APP.storage.store_generated(chat_id, f"gen_{assistant_msg_id}_{idx}.{ext}", raw),
                        "mimeType": img.get("mimeType"),
                    }
                )
            except Exception:
                continue

        debug_obj: dict[str, Any] = {"batch": {"name": batch_name}, "raw": resp}
        if fallback_debug:
            debug_obj.update(fallback_debug)
        debug_rel = APP.storage.save_debug(chat_id, assistant_msg_id, debug_obj)
        APP.storage.set_message(
            chat_id,
            assistant_msg_id,
            {
                "text": text,
                "parts": parts,
                "outputs": outputs,
                "usage": gen_resp.get("usageMetadata"),
                "batch": {"name": batch_name, "state": state},
                "debugPath": debug_rel,
            },
        )
        self._finalize_batch(chat_id, batch_name)
        return self._json(200, {"ok": True, "done": True, "state": state})

    def _finalize_batch(self, chat_id: str, batch_name: str) -> None:
        APP.storage.remove_chat_batch_job(chat_id, batch_name)

        try:
            api = APP.api()
            api.delete_batch(batch_name)
        except Exception:
            pass
        APP.storage.delete_batch(batch_name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=7878, type=int)
    args = parser.parse_args()

    (DATA_DIR / "files").mkdir(parents=True, exist_ok=True)

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Server running on http://{args.host}:{args.port}/")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
