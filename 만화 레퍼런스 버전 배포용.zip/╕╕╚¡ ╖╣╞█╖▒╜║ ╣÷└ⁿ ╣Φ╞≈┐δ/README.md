# Gemini WebApp (local)

## Quick start (Windows)
1. Copy `env.example` to `env`
2. Put your key into `env`:
   - `GEMINI_API_KEY=...`
3. Double-click `run.bat`

The app opens at `http://127.0.0.1:7878/`.

## Notes
- This project keeps all chat logs and generated images under `data/` (ignored by git).
- Batch mode uses the Gemini Batch API (priced at 50% of standard interactive calls). You can cancel or clean up pending batch jobs in the UI.
- The "Batch enqueued tokens" indicator is a local estimate (uses `countTokens` when enabled).
