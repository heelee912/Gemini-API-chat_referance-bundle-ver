const $ = (sel) => document.querySelector(sel);
const el = (tag, cls) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  return e;
};

const state = {
  status: null,
  chats: [],
  chat: null,
  attachments: [],
  settingsOpen: true,
  polling: new Map(),
  sending: false,
  pendingRevokeUrls: [],
  bundleUploadTargetId: null,
  bundleSaveTimers: new Map(),
  bundlePendingPatches: new Map(),
};

const SAFETY_CATEGORIES = [
  { id: "HARM_CATEGORY_HARASSMENT", label: "괴롭힘/모욕" },
  { id: "HARM_CATEGORY_HATE_SPEECH", label: "혐오/차별" },
  { id: "HARM_CATEGORY_SEXUALLY_EXPLICIT", label: "성적 콘텐츠" },
  { id: "HARM_CATEGORY_DANGEROUS_CONTENT", label: "위험/폭력 조장" },
  { id: "HARM_CATEGORY_CIVIC_INTEGRITY", label: "시민 무결성(Deprecated)" },
  { id: "HARM_CATEGORY_DEROGATORY", label: "(구형) 비하 발언" },
  { id: "HARM_CATEGORY_TOXICITY", label: "(구형) 공격적/욕설" },
  { id: "HARM_CATEGORY_VIOLENCE", label: "(구형) 폭력/유혈" },
  { id: "HARM_CATEGORY_SEXUAL", label: "(구형) 성적 행위" },
  { id: "HARM_CATEGORY_MEDICAL", label: "(구형) 의료 조언" },
  { id: "HARM_CATEGORY_DANGEROUS", label: "(구형) 위험 행위" },
];

const THRESHOLDS = [
  { id: "", label: "기본값" },
  { id: "BLOCK_LOW_AND_ABOVE", label: "낮음+ 차단" },
  { id: "BLOCK_MEDIUM_AND_ABOVE", label: "중간+ 차단" },
  { id: "BLOCK_ONLY_HIGH", label: "높음만 차단" },
  { id: "BLOCK_NONE", label: "차단 없음" },
  { id: "OFF", label: "OFF(필터 끔)" },
];

function thresholdIndexFromId(id) {
  return Math.max(
    0,
    THRESHOLDS.findIndex((t) => t.id === id)
  );
}

function saveLocalSettings(obj) {
  localStorage.setItem("gemini_webapp_settings_v1", JSON.stringify(obj));
}
function loadLocalSettings() {
  try {
    return JSON.parse(localStorage.getItem("gemini_webapp_settings_v1") || "{}");
  } catch {
    return {};
  }
}

function fmtTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString();
}

function setHint(text) {
  $("#hint").textContent = text || "";
}

function fileUrlFromStoredPath(storedPath) {
  const p = String(storedPath || "").replaceAll("\\", "/");
  const marker = "data/files/";
  if (p.includes(marker)) return "/files/" + p.split(marker).pop();
  if (p.startsWith("files/")) return "/files/" + p.slice("files/".length);
  if (p.startsWith("outputs/") || p.startsWith("uploads/") || p.startsWith("bundles/")) return "/files/" + p;
  return "/files/" + p.replace(/^\/+/, "");
}

async function apiGet(path) {
  const res = await fetch(path);
  return await res.json();
}

async function apiJson(method, path, body) {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  return await res.json();
}

function currentSettings() {
  const s = {
    systemInstruction: $("#systemInstruction").value || "",
    generationConfig: {},
    tools: [],
    toolConfig: {},
    safetySettings: [],
    estimateBatchTokens: $("#estimateBatchTokens").checked,
  };

  const temp = parseFloat($("#temperature").value);
  const topP = parseFloat($("#topP").value);
  const topK = parseInt($("#topK").value || "0", 10);
  const maxOut = parseInt($("#maxOutputTokens").value || "0", 10);
  const candidateCount = parseInt($("#candidateCount").value || "0", 10);
  const seed = parseInt($("#seed").value || "0", 10);
  const stopSequences = ($("#stopSequences").value || "")
    .split("\n")
    .map((x) => x.trim())
    .filter(Boolean);

  if (!Number.isNaN(temp)) s.generationConfig.temperature = temp;
  if (!Number.isNaN(topP)) s.generationConfig.topP = topP;
  if (Number.isFinite(topK) && topK > 0) s.generationConfig.topK = topK;
  if (Number.isFinite(maxOut) && maxOut > 0) s.generationConfig.maxOutputTokens = maxOut;
  if (Number.isFinite(candidateCount) && candidateCount > 0) s.generationConfig.candidateCount = candidateCount;
  if (Number.isFinite(seed) && seed !== 0) s.generationConfig.seed = seed;
  if (stopSequences.length) s.generationConfig.stopSequences = stopSequences;

  const mediaResolution = $("#mediaResolution").value;
  if (mediaResolution) s.generationConfig.mediaResolution = mediaResolution;

  const thinkingLevel = $("#thinkingLevel").value;
  const includeThoughts = $("#includeThoughts").checked;
  const thinkingBudget = parseInt($("#thinkingBudget").value || "0", 10);
  if (thinkingLevel || includeThoughts || (Number.isFinite(thinkingBudget) && thinkingBudget > 0)) {
    s.generationConfig.thinkingConfig = {};
    if (thinkingLevel) s.generationConfig.thinkingConfig.thinkingLevel = thinkingLevel;
    if (includeThoughts) s.generationConfig.thinkingConfig.includeThoughts = true;
    if (Number.isFinite(thinkingBudget) && thinkingBudget > 0) s.generationConfig.thinkingConfig.thinkingBudget = thinkingBudget;
  }

  const responseType = $("#responseTypeSelect").value;
  if (responseType === "text") {
    s.generationConfig.responseModalities = ["TEXT"];
  } else if (responseType === "text_image") {
    s.generationConfig.responseModalities = ["TEXT", "IMAGE"];
  } else if (responseType === "image") {
    s.generationConfig.responseModalities = ["IMAGE"];
  }

  const jsonMode = $("#jsonMode").checked;
  if (jsonMode) {
    s.generationConfig.responseMimeType = "application/json";
    const schemaText = ($("#jsonSchema").value || "").trim();
    if (schemaText) {
      try {
        s.generationConfig.responseSchema = JSON.parse(schemaText);
      } catch {
        // keep raw in debug via server error
      }
    }
  }

  const selectedModel = $("#modelSelect").value;
  const modelInfo = state.status?.models?.[selectedModel];
  const supportsImageGen = !!modelInfo?.supports?.imageGeneration;
  if (supportsImageGen) {
    const aspectRatio = $("#aspectRatio").value;
    const imageSize = $("#imageSize").value;
    if (aspectRatio || imageSize) {
      s.generationConfig.imageConfig = {};
      if (aspectRatio) s.generationConfig.imageConfig.aspectRatio = aspectRatio;
      if (imageSize) s.generationConfig.imageConfig.imageSize = imageSize;
    }
  }

  if ($("#toolCodeExecution").checked) s.tools.push({ codeExecution: {} });
  if ($("#toolGoogleSearch").checked) s.tools.push({ googleSearch: {} });
  if ($("#toolUrlContext").checked) s.tools.push({ urlContext: {} });

  if ($("#toolFunctionCalling").checked) {
    const raw = ($("#functionDeclarations").value || "").trim();
    if (raw) {
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch {
        throw new Error("Function declarations JSON이 유효하지 않습니다.");
      }
      if (!Array.isArray(parsed)) throw new Error("Function declarations는 JSON 배열이어야 합니다.");
      s.tools.push({ functionDeclarations: parsed });
    } else {
      s.tools.push({ functionDeclarations: [] });
    }

    const mode = $("#functionCallingMode").value || "AUTO";
    const allowed = ($("#allowedFunctionNames").value || "")
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean);
    s.toolConfig.functionCallingConfig = { mode };
    if (allowed.length) s.toolConfig.functionCallingConfig.allowedFunctionNames = allowed;
  }

  // Safety settings
  SAFETY_CATEGORIES.forEach((cat) => {
    const range = document.querySelector(`input[data-safety='${cat.id}']`);
    if (!range) return;
    const idx = parseInt(range.value || "0", 10);
    const threshold = THRESHOLDS[Math.max(0, Math.min(THRESHOLDS.length - 1, idx))]?.id || "";
    if (threshold) s.safetySettings.push({ category: cat.id, threshold });
  });

  if (!s.tools.length) delete s.tools;
  if (!s.safetySettings.length) delete s.safetySettings;
  if (!Object.keys(s.generationConfig).length) delete s.generationConfig;
  if (!Object.keys(s.toolConfig).length) delete s.toolConfig;
  return s;
}

function applySettingsFromLocal() {
  const s = loadLocalSettings();

  $("#systemInstruction").value = s.systemInstruction || "";
  $("#temperature").value = s.temperature ?? "0.7";
  $("#topP").value = s.topP ?? "0.95";
  $("#topK").value = s.topK ?? "";
  $("#maxOutputTokens").value = s.maxOutputTokens ?? "2048";
  $("#candidateCount").value = s.candidateCount ?? "";
  $("#stopSequences").value = (s.stopSequences || []).join("\n");
  $("#seed").value = s.seed ?? "";
  $("#mediaResolution").value = s.mediaResolution || "";
  $("#thinkingLevel").value = s.thinkingLevel || "";
  $("#includeThoughts").checked = !!s.includeThoughts;
  $("#thinkingBudget").value = s.thinkingBudget ?? "";
  $("#jsonMode").checked = !!s.jsonMode;
  $("#jsonSchema").value = s.jsonSchema || "";
  $("#toolCodeExecution").checked = !!s.toolCodeExecution;
  $("#toolGoogleSearch").checked = !!s.toolGoogleSearch;
  $("#toolUrlContext").checked = !!s.toolUrlContext;
  $("#toolFunctionCalling").checked = !!s.toolFunctionCalling;
  $("#functionCallingMode").value = s.functionCallingMode || "AUTO";
  $("#allowedFunctionNames").value = s.allowedFunctionNames || "";
  $("#functionDeclarations").value = s.functionDeclarations || "";
  $("#aspectRatio").value = s.aspectRatio || "";
  $("#imageSize").value = s.imageSize || "";
  $("#batchTier").value = s.batchTier || "tier1";
  $("#estimateBatchTokens").checked = s.estimateBatchTokens ?? true;
}

function persistSettingsToLocal() {
  const s = {
    systemInstruction: $("#systemInstruction").value || "",
    temperature: parseFloat($("#temperature").value),
    topP: parseFloat($("#topP").value),
    topK: $("#topK").value || "",
    maxOutputTokens: parseInt($("#maxOutputTokens").value || "0", 10),
    candidateCount: $("#candidateCount").value || "",
    stopSequences: ($("#stopSequences").value || "")
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean),
    seed: $("#seed").value || "",
    mediaResolution: $("#mediaResolution").value || "",
    thinkingLevel: $("#thinkingLevel").value || "",
    includeThoughts: $("#includeThoughts").checked,
    thinkingBudget: $("#thinkingBudget").value || "",
    jsonMode: $("#jsonMode").checked,
    jsonSchema: $("#jsonSchema").value || "",
    toolCodeExecution: $("#toolCodeExecution").checked,
    toolGoogleSearch: $("#toolGoogleSearch").checked,
    toolUrlContext: $("#toolUrlContext").checked,
    toolFunctionCalling: $("#toolFunctionCalling").checked,
    functionCallingMode: $("#functionCallingMode").value || "AUTO",
    allowedFunctionNames: $("#allowedFunctionNames").value || "",
    functionDeclarations: $("#functionDeclarations").value || "",
    aspectRatio: $("#aspectRatio").value || "",
    imageSize: $("#imageSize").value || "",
    batchTier: $("#batchTier").value || "tier1",
    estimateBatchTokens: $("#estimateBatchTokens").checked,
    safety: SAFETY_CATEGORIES.map((c) => {
      const r = document.querySelector(`input[data-safety='${c.id}']`);
      const idx = r ? parseInt(r.value || "0", 10) : 0;
      const threshold = THRESHOLDS[Math.max(0, Math.min(THRESHOLDS.length - 1, idx))]?.id || "";
      return { category: c.id, threshold };
    }),
  };
  saveLocalSettings(s);
}

function renderSafetySettings() {
  const root = $("#safetySettings");
  root.innerHTML = "";
  for (const cat of SAFETY_CATEGORIES) {
    const row = el("div", "safety-row");
    const top = el("div", "row-top");
    const name = el("div", "name");
    name.textContent = cat.label;
    const val = el("div", "val");
    val.textContent = "기본값";
    top.appendChild(name);
    top.appendChild(val);

    const range = el("input");
    range.type = "range";
    range.min = "0";
    range.max = String(THRESHOLDS.length - 1);
    range.step = "1";
    range.value = "0";
    range.dataset.safety = cat.id;
    range.addEventListener("input", () => {
      const idx = parseInt(range.value || "0", 10);
      val.textContent = THRESHOLDS[Math.max(0, Math.min(THRESHOLDS.length - 1, idx))]?.label || "기본값";
    });
    range.addEventListener("change", () => {
      persistSettingsToLocal();
    });

    row.appendChild(top);
    row.appendChild(range);
    root.appendChild(row);
  }

  // Apply saved values
  const s = loadLocalSettings();
  if (Array.isArray(s.safety)) {
    for (const item of s.safety) {
      if (!item?.category) continue;
      const range = document.querySelector(`input[data-safety='${item.category}']`);
      if (range) {
        const idx = thresholdIndexFromId(item.threshold || "");
        range.value = String(idx);
        range.dispatchEvent(new Event("input"));
      }
    }
  }
}

function renderChatList() {
  const root = $("#chatList");
  root.innerHTML = "";
  for (const c of state.chats) {
    const item = el("div", "chat-item" + (state.chat?.id === c.id ? " active" : ""));
    const left = el("div");
    const title = el("div", "chat-title");
    title.textContent = c.title || "채팅";
    const meta = el("div", "chat-meta");
    meta.textContent = fmtTime(c.updatedAt);
    left.appendChild(title);
    left.appendChild(meta);

    const actions = el("div", "chat-actions");
    const del = el("button", "icon-btn");
    del.textContent = "🗑";
    del.title = "채팅 삭제";
    del.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!confirm("이 채팅을 삭제하시겠습니까? (관련 batch 작업도 취소/삭제 시도합니다)")) return;
      await apiJson("DELETE", `/api/chats/${encodeURIComponent(c.id)}`, {});
      await refreshChats();
      if (state.chat?.id === c.id) {
        state.chat = null;
        renderChatList();
        renderMessages();
        setHint("현재 보고 있던 채팅을 삭제했습니다.");
        setTimeout(() => setHint(""), 1500);
      }
    });
    actions.appendChild(del);

    item.appendChild(left);
    item.appendChild(actions);
    item.addEventListener("click", () => openChat(c.id));
    root.appendChild(item);
  }
}

function renderMessages() {
  const root = $("#messages");
  const scroller = root.parentElement;
  const wasNearBottom =
    !!scroller && scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 80;
  const scrollToBottomIfNeeded = () => {
    if (!scroller) return;
    if (!wasNearBottom) return;
    scroller.scrollTop = scroller.scrollHeight;
  };

  root.innerHTML = "";
  if (!state.chat) return;
  for (const m of state.chat.messages || []) {
    const bubble = el("div", "bubble " + (m.role === "user" ? "user" : "assistant"));
    bubble.textContent = m.text || "";

    const uploads = (m.uploads || []).map((u) => {
      const url = u.previewUrl || fileUrlFromStoredPath(u.path);
      return { url, name: u.name, mimeType: u.mimeType };
    });

    if (uploads.length) {
      const grid = el("div", "images");
      for (const img of uploads) {
        const a = el("a");
        a.href = img.url;
        a.target = "_blank";
        const im = el("img");
        im.src = img.url;
        im.alt = img.name || "upload";
        im.addEventListener("load", scrollToBottomIfNeeded, { once: true });
        a.appendChild(im);
        grid.appendChild(a);
      }
      bubble.appendChild(grid);
    }

    const extraParts = Array.isArray(m.parts) ? m.parts.filter((p) => p && p.type && p.type !== "text" && p.type !== "inlineData") : [];
    if (extraParts.length) {
      const thoughts = extraParts.filter((p) => p.type === "thought").map((p) => p.text).filter(Boolean);
      if (thoughts.length) {
        const details = el("details", "details");
        const summary = el("summary");
        summary.textContent = "Thoughts";
        const pre = el("pre", "pre");
        pre.textContent = thoughts.join("\n\n");
        details.appendChild(summary);
        details.appendChild(pre);
        bubble.appendChild(details);
      }

      const nonThought = extraParts.filter((p) => p.type !== "thought");
      if (nonThought.length) {
        const details = el("details", "details");
        const summary = el("summary");
        summary.textContent = "도구/실행 결과";
        details.appendChild(summary);
        for (const p of nonThought) {
          const pre = el("pre", "pre");
          pre.textContent = JSON.stringify(p, null, 2);
          details.appendChild(pre);
        }
        bubble.appendChild(details);
      }
    }

    const imgs = (m.outputs || []).map((o) => {
      const url = fileUrlFromStoredPath(o.path);
      return { url, name: o.name, mimeType: o.mimeType };
    });

    if (imgs.length) {
      const grid = el("div", "images");
      for (const img of imgs) {
        const a = el("a");
        a.href = img.url;
        a.target = "_blank";
        const im = el("img");
        im.src = img.url;
        im.alt = img.name || "image";
        im.addEventListener("load", scrollToBottomIfNeeded, { once: true });
        a.appendChild(im);
        grid.appendChild(a);
      }
      bubble.appendChild(grid);
    }

    const meta = el("div", "meta");
    const t = el("span");
    t.textContent = fmtTime(m.createdAt);
    meta.appendChild(t);

    if (m.usage) {
      const u = m.usage;
      const usage = el("span");
      const p = typeof u.promptTokenCount === "number" ? u.promptTokenCount : null;
      const c = typeof u.candidatesTokenCount === "number" ? u.candidatesTokenCount : null;
      const th = typeof u.thoughtsTokenCount === "number" ? u.thoughtsTokenCount : null;
      const parts = [];
      if (p != null) parts.push(`in ${p}`);
      if (c != null) parts.push(`out ${c}`);
      if (th != null) parts.push(`thought ${th}`);
      usage.textContent = parts.length ? `tokens: ${parts.join(" / ")}` : "tokens: -";
      meta.appendChild(usage);
    }

    if (m.batch?.state) {
      const st = el("span");
      st.textContent = `batch: ${m.batch.state}`;
      meta.appendChild(st);
    }

    if (m.batch?.name && m.batch?.state && !isTerminalBatchState(m.batch.state)) {
      const cancel = el("button", "btn btn-ghost");
      cancel.textContent = "Batch 취소";
      cancel.addEventListener("click", async () => {
        await apiJson("POST", "/api/batches/cancel", { name: m.batch.name });
        setHint("배치 취소를 요청했습니다. 상태를 갱신 중입니다.");
        startBatchPolling(m.batch.name, state.chat.id, m.id);
        setTimeout(() => setHint(""), 2000);
      });
      meta.appendChild(cancel);
    }

    if (m.debugPath) {
      const dbg = el("button", "btn btn-ghost");
      dbg.textContent = "디버그";
      dbg.addEventListener("click", async () => {
        const data = await apiGet("/api/debug/" + encodeURIComponent(m.debugPath));
        if (!data.ok) return alert("디버그를 불러오지 못했습니다.");
        const w = window.open("", "_blank");
        w.document.write("<pre>" + escapeHtml(JSON.stringify(data.debug, null, 2)) + "</pre>");
      });
      meta.appendChild(dbg);
    }

    if (m.batch?.name && !state.polling.has(m.batch.name)) {
      startBatchPolling(m.batch.name, state.chat.id, m.id);
    }

    bubble.appendChild(meta);
    root.appendChild(bubble);
  }
  scrollToBottomIfNeeded();
  // Some images (blob URLs, large files) can change layout after decode; scroll again next frame.
  requestAnimationFrame(scrollToBottomIfNeeded);
}

function setBundleInState(bundle) {
  if (!state.chat || !bundle?.id) return;
  state.chat.bundles = Array.isArray(state.chat.bundles) ? state.chat.bundles : [];
  const idx = state.chat.bundles.findIndex((b) => b?.id === bundle.id);
  if (idx >= 0) state.chat.bundles[idx] = bundle;
  else state.chat.bundles.unshift(bundle);
}

function removeBundleFromState(bundleId) {
  if (!state.chat) return;
  state.chat.bundles = Array.isArray(state.chat.bundles) ? state.chat.bundles : [];
  state.chat.bundles = state.chat.bundles.filter((b) => b?.id !== bundleId);
}

function scheduleBundleUpdate(bundleId, patch) {
  if (!state.chat) return;
  const pending = state.bundlePendingPatches.get(bundleId) || {};
  state.bundlePendingPatches.set(bundleId, { ...pending, ...patch });
  const prev = state.bundleSaveTimers.get(bundleId);
  if (prev) clearTimeout(prev);
  const t = setTimeout(async () => {
    const merged = state.bundlePendingPatches.get(bundleId) || {};
    state.bundlePendingPatches.delete(bundleId);
    try {
      const data = await apiJson("POST", "/api/bundles/update", { chatId: state.chat.id, bundleId, patch: merged });
      if (data?.ok && data.bundle) {
        setBundleInState(data.bundle);
        renderBundles();
      }
    } catch {
      // ignore
    }
  }, 450);
  state.bundleSaveTimers.set(bundleId, t);
}

async function updateBundleNow(bundleId, patch) {
  if (!state.chat) return;
  const data = await apiJson("POST", "/api/bundles/update", { chatId: state.chat.id, bundleId, patch });
  if (data?.ok && data.bundle) {
    setBundleInState(data.bundle);
    renderBundles();
  }
}

function renderBundles() {
  const root = $("#bundleList");
  if (!root) return;
  root.innerHTML = "";
  if (!state.chat) return;

  const bundles = Array.isArray(state.chat.bundles) ? state.chat.bundles : [];
  if (!bundles.length) {
    const empty = el("div", "bundle-meta");
    empty.textContent = "번들이 없습니다. ‘번들 추가’로 레퍼런스를 만들어 주세요.";
    root.appendChild(empty);
    return;
  }

  for (const b of bundles) {
    if (!b?.id) continue;
    const item = el("div", "bundle-item");

    const top = el("div", "bundle-top");
    const chkLabel = el("label", "field inline");
    const chk = el("input");
    chk.type = "checkbox";
    chk.checked = !!b.selected;
    chk.addEventListener("change", () => {
      updateBundleNow(b.id, { selected: chk.checked });
    });
    const chkSpan = el("span", "field-label");
    chkSpan.textContent = "이번 전송 포함";
    chkLabel.appendChild(chk);
    chkLabel.appendChild(chkSpan);

    const title = el("input", "bundle-title");
    title.value = b.title || "";
    title.placeholder = "번들 제목";
    title.addEventListener("input", () => scheduleBundleUpdate(b.id, { title: title.value }));

    const del = el("button", "btn btn-ghost");
    del.textContent = "삭제";
    del.addEventListener("click", async () => {
      if (!confirm("이 번들을 삭제하시겠습니까?")) return;
      const data = await apiJson("POST", "/api/bundles/delete", { chatId: state.chat.id, bundleId: b.id });
      if (data?.ok) {
        removeBundleFromState(b.id);
        renderBundles();
      }
    });

    top.appendChild(chkLabel);
    top.appendChild(title);
    top.appendChild(del);
    item.appendChild(top);

    const meta = el("div", "bundle-meta");
    const imgs = Array.isArray(b.images) ? b.images : [];
    meta.textContent = `이미지 ${imgs.length}개`;
    item.appendChild(meta);

    const imgGrid = el("div", "bundle-images");
    for (const im of imgs) {
      const thumb = el("div", "bundle-thumb");
      const img = el("img");
      img.src = fileUrlFromStoredPath(im.path);
      img.alt = im.name || "image";
      thumb.appendChild(img);
      const x = el("button");
      x.textContent = "×";
      x.title = "이미지 제거";
      x.addEventListener("click", async () => {
        const data = await apiJson("POST", "/api/bundles/images/delete", { chatId: state.chat.id, bundleId: b.id, imageId: im.id });
        if (data?.ok) {
          setBundleInState({ ...b, images: imgs.filter((z) => z?.id !== im.id) });
          renderBundles();
        }
      });
      thumb.appendChild(x);
      imgGrid.appendChild(thumb);
    }
    item.appendChild(imgGrid);

    const addRow = el("div", "bundle-toolbar");
    const addImg = el("button", "btn btn-secondary");
    addImg.textContent = "이미지 추가";
    addImg.addEventListener("click", () => {
      state.bundleUploadTargetId = b.id;
      $("#bundleFileInput").click();
    });
    addRow.appendChild(addImg);
    item.appendChild(addRow);

    const prompt = el("textarea", "textarea bundle-prompt");
    prompt.rows = 4;
    prompt.placeholder = "이 번들의 프롬프트를 입력해 주세요. (이 번들 이미지에 적용됩니다)";
    prompt.value = b.prompt || "";
    prompt.addEventListener("input", () => scheduleBundleUpdate(b.id, { prompt: prompt.value }));
    item.appendChild(prompt);

    root.appendChild(item);
  }
}

function isTerminalBatchState(state) {
  return ["BATCH_STATE_SUCCEEDED", "BATCH_STATE_FAILED", "BATCH_STATE_CANCELLED", "BATCH_STATE_EXPIRED", "JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"].includes(
    String(state || "")
  );
}

function escapeHtml(str) {
  return (str || "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
}

function renderAttachments() {
  const root = $("#attachmentPreview");
  root.innerHTML = "";
  for (let i = 0; i < state.attachments.length; i++) {
    const f = state.attachments[i];
    const div = el("div", "thumb");
    const img = el("img");
    img.src = f.previewUrl;
    div.appendChild(img);
    const btn = el("button");
    btn.textContent = "×";
    btn.addEventListener("click", () => {
      state.attachments.splice(i, 1);
      renderAttachments();
    });
    div.appendChild(btn);
    root.appendChild(div);
  }
}

async function refreshStatus() {
  state.status = await apiGet("/api/status");
  const sel = $("#modelSelect");
  sel.innerHTML = "";
  for (const [id, info] of Object.entries(state.status.models || {})) {
    const opt = el("option");
    opt.value = id;
    opt.textContent = info.label || id;
    sel.appendChild(opt);
  }

  const saved = loadLocalSettings();
  if (saved.model && state.status.models?.[saved.model]) sel.value = saved.model;

  const ks = $("#apiKeyStatus");
  if (!state.status.apiKeyLoaded) {
    ks.textContent = "API 키가 없습니다. 루트에 env 파일을 만들고 GEMINI_API_KEY=... 를 넣어 주세요.";
  } else {
    ks.textContent = `API 키 로드됨: ${state.status.apiKeyHint}`;
  }
}

async function refreshChats() {
  const data = await apiGet("/api/chats");
  state.chats = data.chats || [];
  renderChatList();
}

async function openChat(chatId) {
  const data = await apiGet(`/api/chats/${encodeURIComponent(chatId)}`);
  if (!data.ok) return;
  state.chat = data.chat;
  renderChatList();
  renderMessages();
  renderBundles();
}

async function createChat() {
  const data = await apiJson("POST", "/api/chats", {});
  if (!data.ok) return;
  await refreshChats();
  await openChat(data.chat.id);
}

function updateCapabilityHints() {
  const model = $("#modelSelect").value;
  const info = state.status?.models?.[model];
  const supports = info?.supports || {};
  const outputModalities = info?.outputModalities || ["TEXT"];

  const responseSel = $("#responseTypeSelect");
  const want = responseSel.value;
  const canImage = outputModalities.includes("IMAGE");
  if (!canImage && (want === "image" || want === "text_image")) {
    responseSel.value = "text";
  }

  $("#toolCodeExecution").disabled = !supports.codeExecution;
  $("#toolUrlContext").disabled = !supports.urlContext;
  $("#toolFunctionCalling").disabled = !supports.functionCalling;

  const imageCard = $("#imageGenCard");
  if (imageCard) imageCard.style.display = supports.imageGeneration ? "" : "none";

  if (!supports.codeExecution) $("#toolCodeExecution").checked = false;
  if (!supports.urlContext) $("#toolUrlContext").checked = false;
  if (!supports.functionCalling) $("#toolFunctionCalling").checked = false;

  const fcOpts = $("#functionCallingOptions");
  if (fcOpts) fcOpts.style.display = $("#toolFunctionCalling").checked ? "" : "none";
}

function bindUI() {
  const setSettingsOpen = (open) => {
    const app = $("#app");
    const panel = $("#settingsPanel");
    state.settingsOpen = !!open;
    if (state.settingsOpen) {
      panel.classList.remove("hidden");
      app.classList.remove("settings-closed");
    } else {
      panel.classList.add("hidden");
      app.classList.add("settings-closed");
    }
  };

  $("#toggleSettingsBtn").addEventListener("click", () => {
    setSettingsOpen(!state.settingsOpen);
  });
  $("#closeSettingsBtn").addEventListener("click", () => {
    setSettingsOpen(false);
  });

  $("#newChatBtn").addEventListener("click", createChat);
  $("#cleanupBatchBtn").addEventListener("click", async () => {
    if (!confirm("로컬에 남아있는 batch 작업들을 정리(취소/삭제 시도)하시겠습니까?")) return;
    await apiJson("POST", "/api/batches/cleanup", {});
    await refreshChats();
    if (state.chat) await openChat(state.chat.id);
  });

  $("#attachBtn").addEventListener("click", () => $("#fileInput").click());
  $("#fileInput").addEventListener("change", async (e) => {
    const files = Array.from(e.target.files || []);
    for (const f of files) {
      const url = URL.createObjectURL(f);
      state.attachments.push({ file: f, previewUrl: url });
    }
    renderAttachments();
    e.target.value = "";
  });

  $("#addBundleBtn")?.addEventListener("click", async () => {
    if (!state.chat) await createChat();
    const data = await apiJson("POST", "/api/bundles/create", { chatId: state.chat.id });
    if (data?.ok && data.bundle) {
      setBundleInState(data.bundle);
      renderBundles();
    }
  });
  $("#clearBundleSelectionBtn")?.addEventListener("click", async () => {
    if (!state.chat) return;
    const bundles = Array.isArray(state.chat.bundles) ? state.chat.bundles : [];
    await Promise.all(
      bundles
        .filter((b) => b?.id && b?.selected)
        .map((b) => apiJson("POST", "/api/bundles/update", { chatId: state.chat.id, bundleId: b.id, patch: { selected: false } }))
    );
    for (const b of bundles) if (b?.id) b.selected = false;
    renderBundles();
  });
  $("#selectAllBundlesBtn")?.addEventListener("click", async () => {
    if (!state.chat) return;
    const bundles = Array.isArray(state.chat.bundles) ? state.chat.bundles : [];
    await Promise.all(
      bundles
        .filter((b) => b?.id && !b?.selected)
        .map((b) => apiJson("POST", "/api/bundles/update", { chatId: state.chat.id, bundleId: b.id, patch: { selected: true } }))
    );
    for (const b of bundles) if (b?.id) b.selected = true;
    renderBundles();
  });

  $("#bundleFileInput")?.addEventListener("change", async (e) => {
    if (!state.chat) return;
    const bundleId = state.bundleUploadTargetId;
    state.bundleUploadTargetId = null;
    const files = Array.from(e.target.files || []).filter((f) => (f.type || "").startsWith("image/"));
    if (!bundleId || !files.length) {
      e.target.value = "";
      return;
    }
    const fd = new FormData();
    fd.append("payload", JSON.stringify({ chatId: state.chat.id, bundleId }));
    for (const f of files) fd.append("files", f, f.name);
    try {
      const res = await fetch("/api/bundles/images/add", { method: "POST", body: fd });
      const data = await res.json();
      if (data?.ok && data.bundle) {
        setBundleInState(data.bundle);
        renderBundles();
      }
    } finally {
      e.target.value = "";
    }
  });

  // Drag & drop
  const composer = $(".composer");
  composer.addEventListener("dragover", (e) => {
    e.preventDefault();
    composer.style.outline = "3px dashed rgba(124, 92, 255, 0.35)";
  });
  composer.addEventListener("dragleave", () => {
    composer.style.outline = "none";
  });
  composer.addEventListener("drop", (e) => {
    e.preventDefault();
    composer.style.outline = "none";
    const files = Array.from(e.dataTransfer.files || []).filter((f) => (f.type || "").startsWith("image/"));
    for (const f of files) {
      const url = URL.createObjectURL(f);
      state.attachments.push({ file: f, previewUrl: url });
    }
    renderAttachments();
  });

  $("#messageInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  $("#messageInput").addEventListener("paste", (e) => {
    try {
      const items = Array.from(e.clipboardData?.items || []);
      const images = items.filter((it) => (it.type || "").startsWith("image/"));
      if (!images.length) return;
      e.preventDefault();
      for (const it of images) {
        const f = it.getAsFile();
        if (!f) continue;
        const url = URL.createObjectURL(f);
        state.attachments.push({ file: f, previewUrl: url });
      }
      renderAttachments();
    } catch {
      // ignore
    }
  });
  $("#sendBtn").addEventListener("click", sendMessage);

  const bindPersist = (id, event = "input") => {
    $(id).addEventListener(event, () => {
      persistSettingsToLocal();
      updateCapabilityHints();
      refreshUsagePanel();
    });
  };
  bindPersist("#systemInstruction", "input");
  bindPersist("#temperature", "input");
  bindPersist("#topP", "input");
  bindPersist("#topK", "input");
  bindPersist("#maxOutputTokens", "input");
  bindPersist("#candidateCount", "input");
  bindPersist("#stopSequences", "input");
  bindPersist("#seed", "input");
  bindPersist("#mediaResolution", "change");
  bindPersist("#thinkingLevel", "change");
  bindPersist("#includeThoughts", "change");
  bindPersist("#thinkingBudget", "input");
  bindPersist("#jsonMode", "change");
  bindPersist("#jsonSchema", "input");
  bindPersist("#toolCodeExecution", "change");
  bindPersist("#toolGoogleSearch", "change");
  bindPersist("#toolUrlContext", "change");
  bindPersist("#toolFunctionCalling", "change");
  bindPersist("#functionCallingMode", "change");
  bindPersist("#allowedFunctionNames", "input");
  bindPersist("#functionDeclarations", "input");
  bindPersist("#aspectRatio", "change");
  bindPersist("#imageSize", "change");
  bindPersist("#modelSelect", "change");
  bindPersist("#sendModeSelect", "change");
  bindPersist("#responseTypeSelect", "change");
  bindPersist("#batchTier", "change");
  bindPersist("#estimateBatchTokens", "change");

  $("#toolFunctionCalling").addEventListener("change", () => {
    const fcOpts = $("#functionCallingOptions");
    if (fcOpts) fcOpts.style.display = $("#toolFunctionCalling").checked ? "" : "none";
  });

  $("#modelSelect").addEventListener("change", () => {
    const s = loadLocalSettings();
    s.model = $("#modelSelect").value;
    saveLocalSettings(s);
    updateCapabilityHints();
  });

  // Value labels
  const syncLabels = () => {
    $("#temperatureVal").textContent = $("#temperature").value;
    $("#topPVal").textContent = $("#topP").value;
  };
  $("#temperature").addEventListener("input", syncLabels);
  $("#topP").addEventListener("input", syncLabels);
  syncLabels();
}

async function sendMessage() {
  if (state.sending) return;
  if (!state.status?.apiKeyLoaded) return alert("API 키가 없습니다. 루트의 env 파일을 확인해 주세요.");
  if (!state.chat) await createChat();

  const text = $("#messageInput").value.trim();
  if (!text && !state.attachments.length) return;

  let settings;
  try {
    settings = currentSettings();
  } catch (e) {
    alert(e?.message || String(e));
    return;
  }

  const payload = {
    chatId: state.chat.id,
    model: $("#modelSelect").value,
    sendMode: $("#sendModeSelect").value,
    text,
    settings,
  };

  setHint(payload.sendMode === "batch" ? "배치로 전송했습니다. 완료될 때까지 기다려 주세요." : "요청 중입니다...");

  // Optimistic UI
  const nowIso = new Date().toISOString();
  const localUserId = `local_user_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const localAssistantId = `local_asst_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const attachments = state.attachments.slice();
  const localUploads = attachments.map((a) => ({
    name: a.file?.name || "image",
    mimeType: a.file?.type || "application/octet-stream",
    previewUrl: a.previewUrl,
  }));
  state.chat.messages = Array.isArray(state.chat.messages) ? state.chat.messages : [];
  state.chat.messages.push({ id: localUserId, role: "user", createdAt: nowIso, text, uploads: localUploads });
  state.chat.messages.push({
    id: localAssistantId,
    role: "assistant",
    createdAt: nowIso,
    text: payload.sendMode === "batch" ? "배치 작업 실행 중입니다. 잠시만 기다려 주세요." : "답변 중입니다. 잠시만 기다려 주세요.",
    batch: payload.sendMode === "batch" ? { state: "pending" } : undefined,
  });
  renderMessages();

  // Clear UI immediately (do not revoke yet; optimistic bubble uses previewUrl)
  $("#messageInput").value = "";
  for (const a of attachments) {
    if (a?.previewUrl) state.pendingRevokeUrls.push(a.previewUrl);
  }
  state.attachments = [];
  renderAttachments();

  const fd = new FormData();
  fd.append("payload", JSON.stringify(payload));
  for (const a of attachments) fd.append("files", a.file, a.file.name);

  $("#sendBtn").disabled = true;
  state.sending = true;
  try {
    const res = await fetch("/api/messages", { method: "POST", body: fd });
    const data = await res.json();
    await refreshChats();
    await openChat(state.chat.id);

    if (data?.ok) {
      // Once the server-stored message replaces the optimistic one, revoke URLs.
      for (const url of state.pendingRevokeUrls.splice(0)) {
        try {
          URL.revokeObjectURL(url);
        } catch {
          // ignore
        }
      }
    }

    if (data.batch?.name) {
      startBatchPolling(data.batch.name, state.chat.id, data.message.id);
    }
  } finally {
    $("#sendBtn").disabled = false;
    state.sending = false;
    setHint("");
  }
}

function startBatchPolling(batchName, chatId, assistantMessageId) {
  if (state.polling.has(batchName)) return;
  const handle = setInterval(async () => {
    try {
      const q = encodeURIComponent(batchName);
      const data = await apiGet(`/api/batch?name=${q}&chatId=${encodeURIComponent(chatId)}&messageId=${encodeURIComponent(assistantMessageId)}`);
      if (data.done) {
        clearInterval(handle);
        state.polling.delete(batchName);
        await openChat(chatId);
      }
    } catch {
      // keep trying
    }
  }, 2000);
  state.polling.set(batchName, handle);
}

async function refreshUsagePanel() {
  const [metricsData, batchesData] = await Promise.all([apiGet("/api/metrics"), apiGet("/api/batches")]);
  const events = metricsData.metrics?.events || [];
  const dayKey = metricsData.metrics?.day || "";
  const tz = metricsData.metrics?.tz || "";
  const today = metricsData.metrics?.today || { calls: 0, tokens: {}, errors: 0 };
  const lastRateInfo = metricsData.metrics?.lastRateInfo || null;
  const batches = batchesData.batches || [];
  const panel = $("#usagePanel");

  // 60s window
  const now = Date.now();
  const recentAll = events
    .map((e) => ({ ...e, ts: Date.parse(e.t) }))
    .filter((e) => Number.isFinite(e.ts) && now - e.ts <= 60_000);

  const recentUser = recentAll.filter((e) => e?.extra?.countAsUserUsage === true);
  const recentBatchCreate = recentAll.filter((e) => e?.kind === "batchGenerateContent");
  const recentBatchPoll = recentAll.filter((e) => e?.kind === "batches.get");

  const rpm = recentUser.length;
  let prompt = 0;
  let cand = 0;
  for (const e of recentUser) {
    const u = e.tokens || {};
    if (typeof u.promptTokenCount === "number") prompt += u.promptTokenCount;
    if (typeof u.candidatesTokenCount === "number") cand += u.candidatesTokenCount;
    if (typeof u.totalTokenCount === "number") {
      // Some calls may only have totalTokenCount
    }
  }

  panel.innerHTML = "";
  const rows = [];
  const tok = today.tokens || {};
  const byKind = today.byKind || {};
  const todayCalls = typeof today.calls === "number" ? today.calls : 0;
  const todayErr = typeof today.errors === "number" ? today.errors : 0;
  const todayPrompt = typeof tok.promptTokenCount === "number" ? tok.promptTokenCount : 0;
  const todayCand = typeof tok.candidatesTokenCount === "number" ? tok.candidatesTokenCount : 0;
  const todayTotal = typeof tok.totalTokenCount === "number" ? tok.totalTokenCount : todayPrompt + todayCand;
  const todayBatchCreate = typeof byKind.batchGenerateContent === "number" ? byKind.batchGenerateContent : 0;
  const todayBatchPoll = typeof byKind["batches.get"] === "number" ? byKind["batches.get"] : 0;
  const todayBatchResult = typeof byKind["batch.result"] === "number" ? byKind["batch.result"] : 0;

  const dayLabel = dayKey ? `오늘(${dayKey})` : "오늘";
  const tzLabel = tz === "America/Los_Angeles" ? "PT" : tz || "local";
  rows.push(`${dayLabel} 누적 요청 수(로컬, ${tzLabel} 기준, 인터랙티브): ${todayCalls}`);
  rows.push(`${dayLabel} 누적 입력 토큰(로컬, 인터랙티브): ${todayPrompt}`);
  rows.push(`${dayLabel} 누적 출력 토큰(로컬, 인터랙티브): ${todayCand}`);
  rows.push(`${dayLabel} 누적 총 토큰(로컬, 인터랙티브): ${todayTotal}`);
  if (todayErr) rows.push(`${dayLabel} 오류 요청 수(로컬): ${todayErr}`);

  rows.push(`최근 60초 요청 수(인터랙티브): ${rpm}`);
  rows.push(`최근 60초 입력 토큰(추정, 인터랙티브): ${prompt}`);
  rows.push(`최근 60초 출력 토큰(추정, 인터랙티브): ${cand}`);
  if (recentBatchCreate.length) rows.push(`최근 60초 batch 생성 API 호출(참고): ${recentBatchCreate.length}`);
  if (recentBatchPoll.length) rows.push(`최근 60초 batch 폴링 API 호출(서버 내부): ${recentBatchPoll.length}`);
  if (todayBatchCreate) rows.push(`${dayLabel} batch 생성 API 호출(참고): ${todayBatchCreate}`);
  if (todayBatchPoll) rows.push(`${dayLabel} batch 폴링 API 호출(서버 내부): ${todayBatchPoll}`);
  if (todayBatchResult) rows.push(`${dayLabel} batch 결과 처리(로컬): ${todayBatchResult}`);

  const concurrentLimit = state.status?.batchRateLimits?.concurrentBatches ?? 100;
  rows.push(`활성 batch 작업: ${batches.length} / ${concurrentLimit}`);

  const tier = $("#batchTier").value || "tier1";
  const limits = state.status?.batchRateLimits?.enqueuedTokensByTier?.[tier] || {};
  const byModel = {};
  for (const b of batches) {
    const model = b.model || "unknown";
    const est = typeof b.estimatedInputTokens === "number" ? b.estimatedInputTokens : 0;
    byModel[model] = (byModel[model] || 0) + est;
  }
  for (const [model, total] of Object.entries(byModel)) {
    const lim = limits?.[model];
    rows.push(`Batch enqueued tokens(추정) ${model}: ${total}${typeof lim === "number" ? ` / ${lim}` : ""}`);
  }

  if (lastRateInfo && typeof lastRateInfo === "object") {
    const keys = Object.keys(lastRateInfo);
    if (keys.length) {
      rows.push("최근 API quota/rate 헤더:");
      for (const k of keys.slice(0, 8)) rows.push(`- ${k}: ${String(lastRateInfo[k])}`);
      if (keys.length > 8) rows.push(`- ... (+${keys.length - 8})`);
    }
  }

  for (const r of rows) {
    const div = el("div");
    div.textContent = r;
    panel.appendChild(div);
  }
}

async function init() {
  renderSafetySettings();
  applySettingsFromLocal();
  bindUI();
  await refreshStatus();
  await refreshChats();
  if (!state.chats.length) await createChat();
  else await openChat(state.chats[0].id);
  updateCapabilityHints();
  refreshUsagePanel();
  setInterval(refreshUsagePanel, 4000);
}

init();
